package edu.sjsu.cmpe275.termproject.Utils;

import edu.sjsu.cmpe275.termproject.models.BookingRequest.BookingRequest;
import edu.sjsu.cmpe275.termproject.models.BookingRequest.SectionRequest;
import edu.sjsu.cmpe275.termproject.models.BookingRequest.TicketRequest;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class ParseRequestTest {
	
	
	@Test
	public void parseBookingRequestMockTest() {
		BookingRequest bookingRequest = ParseRequest.parseBookingRequestMock("");
		
		int numberOfTickets = 2;
		assertEquals(numberOfTickets,bookingRequest.getTicketRequestList().size());
		
		int numberOfSections = 2;
		for (TicketRequest ticketRequest: bookingRequest.getTicketRequestList()) {
			assertEquals(numberOfSections, ticketRequest.getSectionRequestList().size());
		}
		
		// For booking
		String userId = "cIOjVqOMxaXstXM8LMs3c5KXby12";
		boolean isRoundTrip = true;
		assertEquals(isRoundTrip,bookingRequest.isRoundTrip());
		assertEquals(userId,bookingRequest.getPassengerId());
		
	}
	
	@Test
	public void parseBookingRequestTest() {
		
		String request = "{" +
			"    \"passengerId\":  \"cIOjVqOMxaXstXM8LMs3c5KXby12\"," +
			"     \"roundTrip\": true," +
			"     \"totalcost\" :2," +
			"     \"numberOfPassengers\": 3," +
			"     \"ticketRequestList\": [" +
			"        {" +
			"             \"sectionRequestList\": [" +
			"                {" +
			"                    \"origination\":  \"A\"," +
			"                     \"destination\":  \"F\"," +
			"                     \"trainId\":  \"SB600\"," +
			"                     \"date\":  \"2017-12-20 06:00:00\"," +
			"                     \"cost\" : 1" +
			"                }," +
			"                {" +
			"                     \"origination\":  \"F\"," +
			"                     \"destination\":  \"G\"," +
			"                     \"trainId\":  \"SB615\"," +
			"                     \"date\":  \"2017-12-20 06:15:00\"," +
			"                     \"cost\" :  1" +
			"                }" +
			"            ]" +
			"        }," +
			"        {" +
			"             \"sectionRequestList\": [" +
			"                {" +
			"                    \"origination\":  \"G\"," +
			"                    \"destination\":  \"F\"," +
			"                    \"trainId\":  \"NB845\"," +
			"                    \"date\":  \"2017-12-20 08:45:00\"," +
			"                    \"cost\" : 1" +
			"                }," +
			"                {" +
			"                     \"origination\": \"F\"," +
			"                     \"destination\": \"A\"," +
			"                     \"trainId\": \"NB2100\"," +
			"                     \"date\": \"2017-12-20 21:00:00\"," +
			"                     \"cost\" : 1" +
			"                }" +
			"            ]" +
			"        }" +
			"    ]" +
			"}";
		
		
		BookingRequest bookingRequest = ParseRequest.parseBookingRequest(request);
		
		String passengerId = "cIOjVqOMxaXstXM8LMs3c5KXby12";
		boolean isRoundTrip = true;
		int numberOfPassengers = 3;
		int numberOfTickets = 2;
		
		assertEquals(isRoundTrip, bookingRequest.isRoundTrip());
		assertEquals(passengerId, bookingRequest.getPassengerId());
		assertEquals(numberOfPassengers, bookingRequest.getNumberOfPassengers());
		assertEquals(numberOfTickets, bookingRequest.getTicketRequestList().size());
		
		int numberOfSections = 2;
		TicketRequest ticketRequest1 = bookingRequest.getTicketRequestList().get(0);
		assertEquals(numberOfSections, ticketRequest1.getSectionRequestList().size());
		
		SectionRequest request1 = ticketRequest1.getSectionRequestList().get(0);
		assertEquals("A", request1.getOrigination());
		assertEquals("F", request1.getDestination());
		assertEquals("SB600", request1.getTrainId());
		assertEquals("2017-12-20 06:00:00", request1.getDateString());
		
		SectionRequest request2 = ticketRequest1.getSectionRequestList().get(1);
		assertEquals("F", request2.getOrigination());
		assertEquals("G", request2.getDestination());
		assertEquals("SB615", request2.getTrainId());
		assertEquals("2017-12-20 06:15:00", request2.getDateString());
		
		
		TicketRequest ticketRequest2 = bookingRequest.getTicketRequestList().get(1);
		assertEquals(numberOfSections, ticketRequest1.getSectionRequestList().size());
		
		SectionRequest request3 = ticketRequest2.getSectionRequestList().get(0);
		assertEquals("G", request3.getOrigination());
		assertEquals("F", request3.getDestination());
		assertEquals("NB845", request3.getTrainId());
		assertEquals("2017-12-20 08:45:00", request3.getDateString());
		
		SectionRequest request4 = ticketRequest2.getSectionRequestList().get(1);
		assertEquals("F", request4.getOrigination());
		assertEquals("A", request4.getDestination());
		assertEquals("NB2100", request4.getTrainId());
		assertEquals("2017-12-20 21:00:00", request4.getDateString());
		
		
	}
}
