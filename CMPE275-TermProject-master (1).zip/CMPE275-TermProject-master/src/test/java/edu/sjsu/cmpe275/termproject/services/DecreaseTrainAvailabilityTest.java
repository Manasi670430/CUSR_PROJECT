package edu.sjsu.cmpe275.termproject.services;

import edu.sjsu.cmpe275.termproject.Utils.TrainUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;

import javax.persistence.EntityManager;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

@DataJpaTest
@RunWith(SpringRunner.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class DecreaseTrainAvailabilityTest {
	@Autowired
	private EntityManager entityManager;
	
	@Test
	public void test() {
		String origination = "A";
		String destination = "C";
		String trainId = "SB615";
		String date = "2017-12-20 06:15:00";
		List<Integer> availabilityList = new ArrayList<Integer>();
		
		for (int i = 0; i < 26; i++) {
			availabilityList.add(1000);
		}

		int numberOfPassengers = 10;
		TrainUtils.setEntityManager(entityManager);
		TrainUtils.queryGenerator(origination, destination, trainId, date, numberOfPassengers, availabilityList);
	}
}