package edu.sjsu.cmpe275.termproject.Utils;

//import org.json.simple.parser.ParseException;
import java.text.ParseException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(SpringJUnit4ClassRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class TrainUtilsTest {
	private DateFormat dateFormat;
	private Date date;
	
	@Autowired
	EntityManager entityManager;
	
	@Before
	public void setup() {
		this.dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		try {
			
			this.date = dateFormat.parse("2017-12-20 06:00:00");
			
		} catch (ParseException e) {}
	}
	
	@Test
	public void calculateDepartureTimeTest() {
		List<String[]> list = new ArrayList<String[]>();
		String[] list1 = {"Regular", "SB615", "A", "Z", "2017-12-20 06:15:00", "2017-12-20 06:15:00"};
		String[] list2 = {"Regular", "SB615", "B", "Z", "2017-12-20 06:15:00", "2017-12-20 06:23:00"};
		
		String[] list3 = {"Express", "SB600", "A", "Z", "2017-12-20 06:00:00", "2017-12-20 06:00:00"};
		String[] list4 = {"Express", "SB600", "F", "Z", "2017-12-20 06:00:00", "2017-12-20 06:28:00"};
		
		String[] list5 = {"Regular", "NB615", "Z", "A", "2017-12-20 06:15:00", "2017-12-20 06:15:00"};
		String[] list6 = {"Regular", "NB615", "Y", "A", "2017-12-20 06:15:00", "2017-12-20 06:23:00"};
		
		String[] list7 = {"Express", "NB600", "Z", "A", "2017-12-20 06:00:00", "2017-12-20 06:00:00"};
		String[] list8 = {"Express", "NB600", "U", "A", "2017-12-20 06:00:00", "2017-12-20 06:28:00"};
		
		list.add(list1);
		list.add(list2);
		list.add(list3);
		list.add(list4);
		list.add(list5);
		list.add(list6);
		list.add(list7);
		list.add(list8);
		
		int count = 0;
		for (String[] item: list) {
			String trainType = item[0];
			String trainId = item[1];
			String origination = item[2];
			String destination = item[3];
			String dateString = item[4];
			String departureTime = item[5];
			
			try {
				Date date = dateFormat.parse(dateString);
				String departureTimeCal = TrainUtils.calculateDepartureTime(
					origination,
					destination,
					trainId,
					trainType,
					date
				);
				assertEquals(departureTime, departureTimeCal);
				System.out.println("count====" + count);
				count++;
			} catch(ParseException e) {
			
			}
			
		}
		
	}
	
	@Test
	public void calculateArrivalTimeTest() {
		List<String[]> list = new ArrayList<String[]>();
		String[] list1 = {"Regular", "SB615", "A", "Z", "2017-12-20 06:15:00", "2017-12-20 09:32:00"};
		String[] list2 = {"Regular", "SB615", "A", "Y", "2017-12-20 06:15:00", "2017-12-20 09:24:00"};
		
		String[] list3 = {"Express", "SB600", "A", "Z", "2017-12-20 06:00:00", "2017-12-20 08:17:00"};
		String[] list4 = {"Express", "SB600", "A", "U", "2017-12-20 06:00:00", "2017-12-20 07:49:00"};

		String[] list5 = {"Regular", "NB615", "Z", "A", "2017-12-20 06:15:00", "2017-12-20 09:32:00"};
		String[] list6 = {"Regular", "NB615", "Z", "B", "2017-12-20 06:15:00", "2017-12-20 09:24:00"};

		String[] list7 = {"Express", "NB600", "Z", "A", "2017-12-20 06:00:00", "2017-12-20 08:17:00"};
		String[] list8 = {"Express", "NB600", "Z", "F", "2017-12-20 06:00:00", "2017-12-20 07:49:00"};
		
		list.add(list1);
		list.add(list2);
		list.add(list3);
		list.add(list4);
		list.add(list5);
		list.add(list6);
		list.add(list7);
		list.add(list8);

		int count = 0;
		for (String[] item: list) {
			String trainType = item[0];
			String trainId = item[1];
			String origination = item[2];
			String destination = item[3];
			String dateString = item[4];
			String departureTime = item[5];
			
			try {
				Date date = dateFormat.parse(dateString);
				String departureTimeCal = TrainUtils.calculateArrivalTime(
					origination,
					destination,
					trainId,
					trainType,
					date
				);
				assertEquals(departureTime, departureTimeCal);
				System.out.println("count====" + count);
				count++;
			} catch(ParseException e) {
			
			}
			
		}
		
	}
	
	@Test
	public void getTrainIdListTest() {
		List<String> trainIdList = TrainUtils.generateTrainIdList();
		for (String trainId: trainIdList) {
//			System.out.println("trainId=======" + trainId);
		}
		
		assertEquals(61, trainIdList.size());
	}
	
	@Test
	public void getTrainDepartureListTest() {

		List<String> trainDepartureList = TrainUtils.generateTrainDepartureList(date);
		
		for (String trainDeparture: trainDepartureList) {
			
			System.out.println("trainDeparture=======" + trainDeparture);
		}
		
		assertEquals(61, trainDepartureList.size());
		
	}
	
	@Test
	public void getResetTrainAvailabilityQueryHelperTest() {
		List<List<String>> result = TrainUtils.getResetTrainAvailabilityQueryHelper(date, 1000, 30);
		assertEquals(30 * 61 * 2, result.get(0).size());
	}
	
	@Test
	public void getResetTrainAvailabilityQueryTest() {
		
		TrainUtils.setEntityManager(entityManager);
		
		Query query = TrainUtils.getResetTrainAvailabilityQuery(date, 1000, 1);
		
//		assertEquals(30 * 61 * 2, result.get(0).size());
	}
	
	@Test
	public void calculatePrice() {
		List<String[]> list = new ArrayList<String[]>();
		String[] list1 = {"A", "B", "Regular", "SB615", "1"};
		String[] list2 = {"A", "F", "Regular", "SB615", "1"};
		String[] list3 = {"A", "G", "Regular", "SB615", "2"};
		String[] list4 = {"A", "Y", "Regular", "SB1015", "5"};
		
		String[] list5 = {"F", "A", "Express", "NB600", "2"};
		String[] list6 = {"K", "A", "Express", "NB600", "4"};
		String[] list7 = {"P", "A", "Express", "NB600", "6"};
		String[] list8 = {"U", "A", "Express", "NB600", "8"};
		String[] list9 = {"Z", "A", "Express", "NB600", "10"};
		
		list.add(list1);
		list.add(list2);
		list.add(list3);
		list.add(list4);
		list.add(list5);
		list.add(list6);
		list.add(list7);
		list.add(list8);
		list.add(list9);
		
		int count = 0;
		for (String[] item: list) {
			float calcutatedPrice = TrainUtils.calculatePrice(item[0], item[1], item[3], item[2]);
			float realPrice = Float.valueOf(item[4]);
			System.out.println("count^^^^^^^^^^" + count++);
			assertEquals(realPrice, calcutatedPrice, 0);
		}
	}
	
}
