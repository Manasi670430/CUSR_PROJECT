package edu.sjsu.cmpe275.termproject.services;

import edu.sjsu.cmpe275.termproject.Cmpe275TermProjectApplication;
import edu.sjsu.cmpe275.termproject.Utils.ParseRequest;
import edu.sjsu.cmpe275.termproject.Utils.TrainUtils;
import edu.sjsu.cmpe275.termproject.config.AppConfig;
import edu.sjsu.cmpe275.termproject.dao.*;
import edu.sjsu.cmpe275.termproject.models.*;
import edu.sjsu.cmpe275.termproject.models.BookingRequest.BookingRequest;

import edu.sjsu.cmpe275.termproject.models.BookingRequest.SectionRequest;
import edu.sjsu.cmpe275.termproject.models.BookingRequest.TicketRequest;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import java.sql.Array;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(SpringJUnit4ClassRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ContextConfiguration(classes = {Cmpe275TermProjectApplication.class, AppConfig.class})
@Transactional
public class BookingTest{
	
	@Autowired
	private EntityManager entityManager;
	
	@Autowired
	private BookingRepository bookingRepository;
	
	@Autowired
	private TicketRepository ticketRepository;
	
	@Autowired
	private SectionRepository sectionRepository;
	
	@Autowired
	private PassengerRepository passengerRepository;
	
	@Autowired
	private TrainAvailabilityRepository trainAvailabilityRepository;

	@Autowired
	private BookingServiceImpl bookingServiceImpl;
	
	@Autowired
	private EmailService emailService;

	private BookingRequest bookingRequest;
	
	@Before
	public void setup() {
		String jsonRequestBody = "";
		this.bookingRequest = ParseRequest.parseBookingRequestMock(jsonRequestBody);
		bookingRepository.deleteAll();
	}
	
	@Test
	public void trainAvailabilityResetTest() {
		Iterable<Booking> bookingIterable = bookingRepository.findAll();
		Iterable<Ticket> ticketIterable = ticketRepository.findAll();
		Iterable<Section> sectionIterable = sectionRepository.findAll();
		
		assertEquals(false, bookingIterable.iterator().hasNext());
		assertEquals(false, ticketIterable.iterator().hasNext());
		assertEquals(false, sectionIterable.iterator().hasNext());
	}
	
	
	/**
	 * Test Booking
	 */
	@Test
	public void bookingSuccessTest() {

		Booking booking = null;
		try {
			TrainUtils.setEntityManager(entityManager);
			
			// Availability before booking
			List<List<Integer>> availabilityBeforeBooking = new ArrayList<List<Integer>>();
			
			for (TicketRequest ticketRequest: bookingRequest.getTicketRequestList()) {
				System.out.println("Ticket request@@@@@@@@@@@@@@@@@@");
				for (SectionRequest sectionRequest: ticketRequest.getSectionRequestList()) {
					
					System.out.println(sectionRequest.getTrainId() + "$$$$$$$$$$$$:");
					String trainId = sectionRequest.getTrainId();
					Date date = sectionRequest.getDate();
					
					TrainAvailabilityId trainAvailabilityId = new TrainAvailabilityId(trainId, date);
					TrainAvailability trainAvailability = trainAvailabilityRepository.findOne(trainAvailabilityId);
					
					int origin;
					int destination;
					List<Integer> list = new ArrayList<>();
					
					if (trainAvailability.getTrainId().toUpperCase().contains("SB")) {
						origin = sectionRequest.getOrigination().toUpperCase().charAt(0) - 'A';
						destination = sectionRequest.getDestination().toUpperCase().charAt(0) - 'A';
						
						for (int i = origin; i <= destination; i++) {
							list.add(trainAvailability.getAvailability().get(i));
							System.out.print((char)('A' + i) + ":" + trainAvailability.getAvailability().get(i) + ", ");
						}
						
					} else {
						
						origin = sectionRequest.getOrigination().toUpperCase().charAt(0) - 'A';
						destination = sectionRequest.getDestination().toUpperCase().charAt(0) - 'A';
						
						for (int i = destination; i <= origin; i++) {
							list.add(trainAvailability.getAvailability().get(i));
							System.out.print((char)('A' + i) + ":" + trainAvailability.getAvailability().get(i) + ", ");
						}
					}
					
					availabilityBeforeBooking.add(list);
					System.out.println("");
				}
				System.out.println();
			}
			
			booking = bookingServiceImpl.book(this.bookingRequest);
			booking = bookingRepository.findOne(booking.getId());
			
			// Availability before booking
			List<List<Integer>> availabilityAfterBooking = new ArrayList<List<Integer>>();
			
			for (Ticket ticket: booking.getTicketList()) {
				System.out.print("Ticket " + ticket.getId() + "=======");
				for (Section section: ticket.getSectionList()) {
					TrainAvailability trainAvailability = section.getTrainAvailability();
					System.out.print(trainAvailability.getTrainId() + "++++++:");
					
					int origin;
					int destination;
					List<Integer> list = new ArrayList<>();
					
					if (trainAvailability.getTrainId().toUpperCase().contains("SB")) {
						origin = section.getOrigination().toUpperCase().charAt(0) - 'A';
						destination = section.getDestination().toUpperCase().charAt(0) - 'A';
						for (int i = origin; i <= destination; i++) {
							list.add(trainAvailability.getAvailability().get(i));
							System.out.print((char)('A' + i) + ":" + trainAvailability.getAvailability().get(i) + ", ");
						}
						
					} else {
						origin = section.getOrigination().toUpperCase().charAt(0) - 'A';
						destination = section.getDestination().toUpperCase().charAt(0) - 'A';
						for (int i = destination; i <= origin; i++) {
							list.add(trainAvailability.getAvailability().get(i));
							System.out.print((char)('A' + i) + ":" + trainAvailability.getAvailability().get(i) + ", ");
						}
					}
					availabilityAfterBooking.add(list);
					System.out.println("");
				}
				System.out.println();
			}
			
			assertEquals(this.bookingRequest.getPassengerId(), booking.getPassenger().getUserId());
			assertEquals(this.bookingRequest.isRoundTrip(), booking.isRoundTrip());
			assertEquals(this.bookingRequest.getNumberOfPassengers(), booking.getNumberOfPassengers());
			
			
			
		} catch (SQLException e) {
			throw new RuntimeException(e);
			
		}
	}
	
	
	
	@Test
	public void bookingFailedTest() {
	
	}
}
