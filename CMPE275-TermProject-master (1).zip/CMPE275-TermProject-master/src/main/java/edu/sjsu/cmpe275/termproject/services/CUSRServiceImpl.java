/**
 * 
 */
package edu.sjsu.cmpe275.termproject.services;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

import com.fasterxml.jackson.databind.util.JSONPObject;
import edu.sjsu.cmpe275.termproject.Utils.TrainUtils;
import edu.sjsu.cmpe275.termproject.dao.*;
import edu.sjsu.cmpe275.termproject.dao.PassengerRepository;
import edu.sjsu.cmpe275.termproject.models.*;
import edu.sjsu.cmpe275.termproject.models.BookingRequest.BookingRequest;
import org.joda.time.DateTime;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.joda.time.format.DateTimeFormat;
import edu.sjsu.cmpe275.termproject.dao.TrainRepository;
import edu.sjsu.cmpe275.termproject.models.Train;
import javax.print.attribute.standard.Destination;

/**
 * @author Abhishek
 *
 */
@Service
public class CUSRServiceImpl implements CUSRService {
    
    @Autowired
    EmailService emailService;
    
    private boolean enableEmail = true;

    @Autowired
    private PassengerRepository passengerRepository;

	@Autowired
	private TrainRepository trainRepository;
 
	@Autowired
	private TrainAvailabilityRepository trainAvailabilityRepository;

	@Autowired
    private BookingRepository bookingRepository;

	@Autowired
    private TicketRepository ticketRepository;

	@Autowired
	private SectionRepository sectionRepository;

	@Autowired
    private SearchRequest request;


    private HashMap<String, Integer> stCounMap;

	public CUSRServiceImpl()
    {
        stCounMap = new HashMap<>();
        stCounMap.put("A",1);
        stCounMap.put("B",2);
        stCounMap.put("C",3);
        stCounMap.put("D",4);
        stCounMap.put("E",5);
        stCounMap.put("F",6);
        stCounMap.put("G",7);
        stCounMap.put("H",8);
        stCounMap.put("I",9);
        stCounMap.put("J",10);
        stCounMap.put("K",11);
        stCounMap.put("L",12);
        stCounMap.put("M",13);
        stCounMap.put("N",14);
        stCounMap.put("O",15);
        stCounMap.put("P",16);
        stCounMap.put("Q",17);
        stCounMap.put("R",18);
        stCounMap.put("S",19);
        stCounMap.put("T",20);
        stCounMap.put("U",21);
        stCounMap.put("V",22);
        stCounMap.put("W",23);
        stCounMap.put("X",24);
        stCounMap.put("Y",25);
        stCounMap.put("Z",26);

    }
    

	@Override
	public JSONObject fetchTrain(String departureTime,String returnTime, String origin, String destination, String trainType, int noOfPassengers, int noOfConnections,boolean isRoundTrip,boolean isExactTime) {
        // TODO Auto-generated method stub

        List<Train> trains = null;
        if(trainType.equalsIgnoreCase("Regular"))
            trains = trainRepository.findByType(trainType);
        else if(trainType.equalsIgnoreCase("Express"))
        {
            if(getStationDiffCount(origin,destination)%5<5 && getStationDiffCount(origin,destination)%5!=0)
            {
                trains = trainRepository.findByType("Regular");
            }
            else
            {
                trains = trainRepository.findAll();
            }
        }
        else
        {
            trains = trainRepository.findAll();
        }


        int originAvailability = 0;
        int destinationAvailability = 0;
        int arriveAtStation = 0;
        int departFromStation = 0;

        JSONObject results = new JSONObject();

        results.put("isRoundTrip", isRoundTrip);


        JSONArray itinerariesArr = new JSONArray();
        JSONArray itinerariesArr1 = new JSONArray();

        List<JSONObject> itinerariesArr1List = new ArrayList<>();
        List<JSONObject> itinerariesArrList = new ArrayList<>();
        List<List<JSONObject>> itinerariesFinalArrList = new ArrayList<>();

        List<Train> sbNBTrains = new ArrayList<>();

        int stCount = getStationDiffCount(origin, destination);

        if(stCount==1)
            noOfConnections = 0;


        if (stCount > 0) {
            for (Train train :
                    trains) {
                if (train.getId().contains("SB"))
                    sbNBTrains.add(train);
            }
        } else {
            for (Train train :
                    trains) {
                if (train.getId().contains("NB"))
                    sbNBTrains.add(train);
            }
        }

        for (Train train :
                    sbNBTrains) {

                JSONObject itineraryObject = new JSONObject();

                JSONObject trainObject = new JSONObject();

                JSONObject sectionObj = new JSONObject();


                List<TrainAvailability> trainAvailabilityList = train.getTrainAvailabilityList();

                TrainAvailability availableTrain = null;


                for (TrainAvailability trainAvailability :
                        trainAvailabilityList) {

                    org.joda.time.format.DateTimeFormatter formatter = org.joda.time.format.DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");

                    DateTime requestTime = new DateTime();

/*
                    if(trainType.contains("roundtrip") && isRoundTrip)
                    {
                        //isRoundTrip = false;
                        trainType = trainType.split(":")[0];
                        requestTime = formatter.parseDateTime(returnTime);
                    }

                    else*/
                    requestTime = formatter.parseDateTime(departureTime);

                    DateTime trainTime = formatter.parseDateTime(trainAvailability.getDateString());

                    if (trainTime.equals(requestTime) || trainTime.isAfter(requestTime))
                    {
                        availableTrain = trainAvailability;
                        break;
                    }


                }

                    if (availableTrain != null) {
                        if (origin.equals("A")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getA();
                                originAvailability = availableTrain.getA();
                            }
                        }
                        if (origin.equals("B")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getB();
                                originAvailability = availableTrain.getB();
                            }
                        }
                        if (origin.equals("C")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getC();
                                originAvailability = availableTrain.getC();
                            }
                        }
                        if (origin.equals("D")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getD();
                                originAvailability = availableTrain.getD();
                            }
                        }
                        if (origin.equals("E")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getE();
                                originAvailability = availableTrain.getE();
                            }
                        }
                        if (origin.equals("F")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getF();
                                originAvailability = availableTrain.getF();
                            }
                        }
                        if (origin.equals("G")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getG();
                                originAvailability = availableTrain.getG();
                            }
                        }
                        if (origin.equals("H")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getH();
                                originAvailability = availableTrain.getH();
                            }
                        }
                        if (origin.equals("I")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getI();
                                originAvailability = availableTrain.getI();
                            }
                        }
                        if (origin.equals("J")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getJ();
                                originAvailability = availableTrain.getJ();
                            }
                        }
                        if (origin.equals("K")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getK();
                                originAvailability = availableTrain.getK();
                            }
                        }
                        if (origin.equals("L")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getA();
                                originAvailability = availableTrain.getA();
                            }
                        }
                        if (origin.equals("M")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getM();
                                originAvailability = availableTrain.getM();
                            }
                        }
                        if (origin.equals("N")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getN();
                                originAvailability = availableTrain.getN();
                            }
                        }
                        if (origin.equals("O")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getO();
                                originAvailability = availableTrain.getO();
                            }
                        }
                        if (origin.equals("P")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getP();
                                originAvailability = availableTrain.getP();
                            }
                        }
                        if (origin.equals("P")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getP();
                                originAvailability = availableTrain.getP();
                            }
                        }
                        if (origin.equals("P")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getP();
                                originAvailability = availableTrain.getP();
                            }
                        }
                        if (origin.equals("P")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getP();
                                originAvailability = availableTrain.getP();
                            }
                        }
                        if (origin.equals("Q")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getQ();
                                originAvailability = availableTrain.getQ();
                            }
                        }
                        if (origin.equals("R")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getR();
                                originAvailability = availableTrain.getR();
                            }
                        }
                        if (origin.equals("S")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getS();
                                originAvailability = availableTrain.getS();
                            }
                        }
                        if (origin.equals("T")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getT();
                                originAvailability = availableTrain.getT();
                            }
                        }
                        if (origin.equals("U")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getU();
                                originAvailability = availableTrain.getU();
                            }
                        }
                        if (origin.equals("U")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getU();
                                originAvailability = availableTrain.getU();
                            }
                        }
                        if (origin.equals("U")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getU();
                                originAvailability = availableTrain.getU();
                            }
                        }
                        if (origin.equals("U")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getU();
                                originAvailability = availableTrain.getU();
                            }
                        }
                        if (origin.equals("V")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getV();
                                originAvailability = availableTrain.getV();
                            }
                        }
                        if (origin.equals("W")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getW();
                                originAvailability = availableTrain.getW();
                            }
                        }
                        if (origin.equals("X")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getX();
                                originAvailability = availableTrain.getX();
                            }
                        }
                        if (origin.equals("Y")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getY();
                                originAvailability = availableTrain.getV();
                            }
                        }
                        if (origin.equals("Z")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                departFromStation = train.getZ();
                                originAvailability = availableTrain.getV();
                            }
                        }

                        if (destination.equals("A")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getA() - 3;
                                destinationAvailability = availableTrain.getB();
                            }


                        }

                        if (destination.equals("B")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getB() - 3;
                                destinationAvailability = availableTrain.getB();
                            }


                        }
                        if (destination.equals("C")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getC() - 3;
                                destinationAvailability = availableTrain.getC();
                            }
                        }
                        if (destination.equals("D")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getD() - 3;
                                destinationAvailability = availableTrain.getD();
                            }
                        }
                        if (destination.equals("E")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getE() - 3;
                                destinationAvailability = availableTrain.getE();
                            }
                        }
                        if (destination.equals("F")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getF() - 3;
                                destinationAvailability = availableTrain.getF();
                            }
                        }
                        if (destination.equals("G")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getG() - 3;
                                destinationAvailability = availableTrain.getG();
                            }
                        }
                        if (destination.equals("H")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getH() - 3;
                                destinationAvailability = availableTrain.getH();
                            }
                        }
                        if (destination.equals("I")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getI() - 3;
                                destinationAvailability = availableTrain.getI();
                            }
                        }
                        if (destination.equals("J")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getJ() - 3;
                                destinationAvailability = availableTrain.getJ();
                            }
                        }
                        if (destination.equals("K")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getK() - 3;
                                destinationAvailability = availableTrain.getK();
                            }
                        }
                        if (destination.equals("L")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getL() - 3;
                                destinationAvailability = availableTrain.getL();
                            }
                        }
                        if (destination.equals("M")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getM() - 3;
                                destinationAvailability = availableTrain.getM();
                            }
                        }
                        if (destination.equals("N")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getN() - 3;
                                destinationAvailability = availableTrain.getN();
                            }
                        }
                        if (destination.equals("O")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getO() - 3;
                                destinationAvailability = availableTrain.getO();
                            }
                        }
                        if (destination.equals("P")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getP() - 3;
                                destinationAvailability = availableTrain.getP();
                            }
                        }
                        if (destination.equals("Q")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getQ() - 3;
                                destinationAvailability = availableTrain.getQ();
                            }
                        }
                        if (destination.equals("R")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getR() - 3;
                                destinationAvailability = availableTrain.getR();
                            }
                        }
                        if (destination.equals("S")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getS() - 3;
                                destinationAvailability = availableTrain.getS();
                            }
                        }
                        if (destination.equals("T")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getT() - 3;
                                destinationAvailability = availableTrain.getT();
                            }
                        }
                        if (destination.equals("U")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getU() - 3;
                                destinationAvailability = availableTrain.getU();
                            }
                        }
                        if (destination.equals("V")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getV() - 3;
                                destinationAvailability = availableTrain.getV();
                            }
                        }
                        if (destination.equals("W")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getW() - 3;
                                destinationAvailability = availableTrain.getW();
                            }
                        }
                        if (destination.equals("X")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getX() - 3;
                                destinationAvailability = availableTrain.getX();
                            }
                        }
                        if (destination.equals("Y")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getY() - 3;
                                destinationAvailability = availableTrain.getY();
                            }
                        }
                        if (destination.equals("Z")) {
                            if (availableTrain.getTrainId().equals(train.getId())) {
                                arriveAtStation = train.getZ() - 3;
                                destinationAvailability = availableTrain.getZ();
                            }
                        }

                        int fare = 0;
                        JSONArray sectionObjArr = new JSONArray();
                        if (noOfConnections == 1) {
                            sectionObjArr = getConnectingTrains(origin, destination, availableTrain, noOfPassengers, trainType, isRoundTrip, isExactTime);


                            fare = getFare(origin, destination, train.getType());

                            //if (originAvailability > 0 && originAvailability >= noOfPassengers && destinationAvailability > 0 && destinationAvailability >= noOfPassengers) {
                            trainObject.put("trainId", availableTrain.getTrainId());
                            trainObject.put("origin", origin);
                            trainObject.put("destination", destination);

                            //DateTimeFormatter formatter = new DateTimeFormatterBuilder().append(ISODateTimeFormat.dateTimeNoMillis()).toFormatter().withOffsetParsed();

                            //String departTime = availableTrain.getDate().toString();
                            //trainObject.put("departure", departTime.substring(0,departTime.length()-2));

                            //trainObject.put("departure", departTime);


                            String departTm = "";

                            String departFromSt = String.valueOf(departFromStation);

                            if (departFromSt.length() == 3) {
                                departTm = "0" + departFromSt.substring(0, 1) + ":" + departFromSt.substring(1) + ":" + "00";
                            }
                            if (departFromSt.length() == 4) {
                                departTm = departFromSt.substring(0, 2) + ":" + departFromSt.substring(2) + ":" + "00";
                            }


                            //DateTimeFormatter formatter = new DateTimeFormatterBuilder().append(ISODateTimeFormat.dateTimeNoMillis()).toFormatter().withOffsetParsed();

                            //String departTime = availableTrain.getDate().toString();
                            trainObject.put("departure", availableTrain.getDate().toString().split(" ")[0] + " " + departTm);


                            String arrivalTime = "";

                            String arrivalStVal = String.valueOf(arriveAtStation);

                            if (arrivalStVal.length() == 3) {
                                arrivalTime = "0" + arrivalStVal.substring(0, 1) + ":" + arrivalStVal.substring(1) + ":" + "00";
                            }
                            if (arrivalStVal.length() == 4) {
                                arrivalTime = arrivalStVal.substring(0, 2) + ":" + arrivalStVal.substring(2) + ":" + "00";
                            }


                            trainObject.put("arrival", availableTrain.getDate().toString().split(" ")[0] + " " + arrivalTime);
                            trainObject.put("totalPrice", fare);
                            trainObject.put("numberOfPassengers", noOfPassengers);
                            trainObject.put("numberOfStops", noOfConnections);
                            trainObject.put("type", train.getType());
                            //section obj to be created
                            trainObject.put("sections", sectionObjArr);

                        }

                        if (noOfConnections == 0) {

                            fare = getFare(origin, destination, train.getType());

                            if (originAvailability > 0 && originAvailability >= noOfPassengers && destinationAvailability > 0 && destinationAvailability >= noOfPassengers) {

                                trainObject.put("trainId", availableTrain.getTrainId());
                                trainObject.put("origin", origin);
                                trainObject.put("destination", destination);


                                String departTm = "";

                                String departFromSt = String.valueOf(departFromStation);

                                if (departFromSt.length() == 3) {
                                    departTm = "0" + departFromSt.substring(0, 1) + ":" + departFromSt.substring(1) + ":" + "00";
                                }
                                if (departFromSt.length() == 4) {
                                    departTm = departFromSt.substring(0, 2) + ":" + departFromSt.substring(2) + ":" + "00";
                                }


                                //DateTimeFormatter formatter = new DateTimeFormatterBuilder().append(ISODateTimeFormat.dateTimeNoMillis()).toFormatter().withOffsetParsed();

                                //String departTime = availableTrain.getDate().toString();
                                trainObject.put("departure", availableTrain.getDate().toString().split(" ")[0] + " " + departTm);

                                String arrivalTime = "";

                                String arrivalStVal = String.valueOf(arriveAtStation);

                                if (arrivalStVal.length() == 3) {
                                    arrivalTime = "0" + arrivalStVal.substring(0, 1) + ":" + arrivalStVal.substring(1) + ":" + "00";
                                }
                                if (arrivalStVal.length() == 4) {
                                    arrivalTime = arrivalStVal.substring(0, 2) + ":" + arrivalStVal.substring(2) + ":" + "00";
                                }


                                trainObject.put("arrival", availableTrain.getDate().toString().split(" ")[0] + " " + arrivalTime);
                                trainObject.put("totalPrice", fare);
                                trainObject.put("numberOfPassengers", noOfPassengers);
                                trainObject.put("numberOfStops", noOfConnections);
                                trainObject.put("type", train.getType());
                                trainObject.put("sections", sectionObjArr);
                            }

                        }

                        itineraryObject.put("from", trainObject);
                        if (isRoundTrip) {

                            String arrivalTime = "";
                            String arrivalStVal = String.valueOf(arriveAtStation);

                            if (arrivalStVal.length() == 3) {
                                arrivalTime = "0" + arrivalStVal.substring(0, 1) + ":" + arrivalStVal.substring(1) + ":" + "00";
                            }
                            if (arrivalStVal.length() == 4) {
                                arrivalTime = arrivalStVal.substring(0, 2) + ":" + arrivalStVal.substring(2) + ":" + "00";
                            }
                            String originStartTime = availableTrain.getDate().toString();

                            String originDepartTime = originStartTime.substring(0,originStartTime.length()-2);

                            String roundTripDeptTime = returnTime;

                            org.joda.time.format.DateTimeFormatter formatter = org.joda.time.format.DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");

                            DateTime rtDateDeptTime = new DateTime();
                            if (roundTripDeptTime != null && !roundTripDeptTime.equals(""))
                                rtDateDeptTime = formatter.parseDateTime(roundTripDeptTime);



                            DateTime originDepart = formatter.parseDateTime(originDepartTime);

                            String arrivalTimeAtDestination = availableTrain.getDate().toString().split(" ")[0] + " " + arrivalTime;
                            DateTime arrivalTimeAtDest = formatter.parseDateTime(arrivalTimeAtDestination);

                            JSONObject returnTripObject = null;

                            if (rtDateDeptTime.isAfter(arrivalTimeAtDest) && rtDateDeptTime.isBefore(originDepart.plusDays(7))) {
                                returnTripObject = fetchTrain(roundTripDeptTime, "", destination, origin, trainType, noOfPassengers, noOfConnections, false, isExactTime);

                            /*trainObject.put("trainId", availableTrain.getTrainId());
                            trainObject.put("origin", origin);
                            trainObject.put("destination", destination);

                            trainObject.put("departure", availableTrain.getDate().toString().split(" ")[0] + " "+ departTm);




                            trainObject.put("arrival", availableTrain.getDate().toString().split(" ")[0] + " "+ arrivalTime);
                            trainObject.put("totalPrice", fare);
                            trainObject.put("numberOfPassengers", noOfPassengers);
                            trainObject.put("numberOfStops", noOfConnections);
                            trainObject.put("type", train.getType());
                            trainObject.put("sections", sectionObjArr);

                            JSONObject returnTrainInfo = new JSONObject();*/

                                CopyOnWriteArrayList<JSONObject> itineraries = (CopyOnWriteArrayList<JSONObject>) returnTripObject.get("itineraries");


                                itineraryObject.put("return", itineraries.get(0).get("from"));
                            }


                        }

                        else
                            itineraryObject.put("return", "");

                        itinerariesArr.add(itineraryObject);

                }

            }

            // sorting the itineraries array with arrival time and taking top 5 results intineraries

            int itineraryCount = 0;
            CopyOnWriteArrayList<JSONObject> objList = new CopyOnWriteArrayList<>();
            for (Object itineraryObject:
                    itinerariesArr) {
                JSONObject obj = (JSONObject) itineraryObject;

                objList.add(obj);
            }

            for (JSONObject obj1 :
                    objList) {
                itineraryCount++;
                if(itineraryCount>5)
                {
                    objList.remove(obj1);
                }

            }
            results.put("itineraries", objList);

            return results;
    }

    public int getFare(String origin,String destination, String trainType)
    {
        int fare = 0;
        int stationCount = getStationDiffCount(origin, destination);

        if(trainType.equals("Express"))
        {
            if (stationCount <= 5)
                fare = 2;
            else if (stationCount <= 10 && stationCount > 5)
                fare = 4;
            else if (stationCount <= 15 && stationCount > 10)
                fare = 6;
            else if (stationCount <= 20 && stationCount > 15)
                fare = 8;
            else if (stationCount <= 25 && stationCount > 20)
                fare = 10;
            else
                fare = 12;
        }
        if(trainType.equals("Regular"))
        {
            if (stationCount <= 5)
                fare = 1;
            else if (stationCount <= 10 && stationCount > 5)
                fare = 2;
            else if (stationCount <= 15 && stationCount > 10)
                fare = 3;
            else if (stationCount <= 20 && stationCount > 15)
                fare = 4;
            else if (stationCount <= 25 && stationCount > 20)
                fare = 5;
            else
                fare = 6;
        }

        return fare;
    }


    public JSONArray getConnectingTrains(String origin, String destination, TrainAvailability availableTrain, int noOfPassengers, String trainType, boolean isRoundTrip,boolean isExactTime)
    {
        JSONArray connectingTrainsArr = new JSONArray();

        List<Connection> connections = availableTrain.getConnections();

        for (Connection connection:
             connections) {
            if(connection.getOrigin().equals(origin))
            {
                if(getStationDiffCount(connection.getOrigin(),connection.getDestination())<getStationDiffCount(origin,destination))
                {

                    JSONObject connectingObj1 = new JSONObject();
                    JSONObject connectingObj2 = new JSONObject();
                    connectingObj1.put("trainId", availableTrain.getTrainId());
                    connectingObj1.put("origin", origin);
                    connectingObj1.put("destination", connection.getDestination());
                    String departTime = availableTrain.getDate().toString();
                    connectingObj1.put("departure", departTime.substring(0,departTime.length()-2));


                    int stCount = getStationDiffCount(origin,connection.getDestination());

                    String arrivalTime = "";

                    String arrivalStVal = String.valueOf(Integer.parseInt(availableTrain.getTrainId().substring(2)) + 8*stCount);

                    if(arrivalStVal.length()==3)
                    {
                        arrivalTime =  "0" + arrivalStVal.substring(0,1) + ":" + arrivalStVal.substring(1) + ":" + "00";
                    }
                    if(arrivalStVal.length()==4)
                    {
                        arrivalTime = arrivalStVal.substring(0,1) + ":" + arrivalStVal.substring(2) + ":" + "00";
                    }

                    String arriveAtSt = availableTrain.getDate().toString().split(" ")[0] + " "+ arrivalTime;

                    connectingObj1.put("arrival", arriveAtSt);


                    connectingObj1.put("totalPrice", getFare(origin,connection.getDestination(),trainType));
                    connectingObj1.put("numberOfPassengers", noOfPassengers);
                    connectingObj1.put("numberOfStops", 0);
                    connectingObj1.put("type", trainType);

                    connectingTrainsArr.add(connectingObj1);


                    connectingObj2 = fetchTrain(arriveAtSt,"", connection.getDestination(),destination,"any",noOfPassengers,0,isRoundTrip,isExactTime);


                    org.joda.time.format.DateTimeFormatter formatter = org.joda.time.format.DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");

                    DateTime maxTimeToWait = formatter.parseDateTime(arriveAtSt).plusHours(2);


                    CopyOnWriteArrayList<JSONObject> itineraries = (CopyOnWriteArrayList<JSONObject>) connectingObj2.get("itineraries");

                    for (JSONObject itineraryObj :
                            itineraries) {

                        DateTime departureTime = formatter.parseDateTime(((JSONObject)itineraryObj.get("from")).get("departure").toString());
                        if(departureTime.isBefore(maxTimeToWait))
                        {
                            JSONObject object = new JSONObject();
                            object.put("trainId", ((JSONObject)itineraryObj.get("from")).get("trainId").toString());
                            object.put("origin", ((JSONObject)itineraryObj.get("from")).get("origin").toString());
                            object.put("destination", ((JSONObject)itineraryObj.get("from")).get("destination").toString());
                            object.put("departure", ((JSONObject)itineraryObj.get("from")).get("departure").toString());

                            object.put("arrival", ((JSONObject)itineraryObj.get("from")).get("arrival").toString());


                            object.put("totalPrice", ((JSONObject)itineraryObj.get("from")).get("totalPrice"));
                            object.put("numberOfPassengers", ((JSONObject)itineraryObj.get("from")).get("numberOfPassengers").toString());
                            object.put("numberOfStops", ((JSONObject)itineraryObj.get("from")).get("numberOfStops").toString());
                            object.put("type", ((JSONObject)itineraryObj.get("from")).get("type").toString());

                            connectingTrainsArr.add(object);
                        }

                    }


                    //connectingTrainsArr.add(connectingObj1);


                }

            }
        }


        CopyOnWriteArrayList<JSONObject> connectingList = new CopyOnWriteArrayList<>(connectingTrainsArr);

        JSONArray finalArr = new JSONArray();
        int count = 0;
        for (JSONObject obj :
                connectingList) {
                count++;
                if(count>2)
                {
                    connectingList.remove(obj);
                    continue;
                }
              finalArr.add(obj);
        }


        return finalArr;

    }

    @Override
    public Passenger fetchUser(String userId) {
	    Passenger passenger =  passengerRepository.findByUserId(userId);
	    return passenger;
    }


    public int getStationDiffCount(String origin, String destination)
    {
        if(stCounMap.containsKey(origin) && stCounMap.containsKey(destination))
        {
            int originCount = stCounMap.get(origin);
            int destCount = stCounMap.get(destination);
            return destCount-originCount;
        }

        return 0;
    }



	@Override
	public Train bookTrain(String trainNo) {
		// TODO Auto-generated method stub
		return null;
	}

    @Override
    public Passenger registerPassenger(String userId, String name, String email) {

	    Passenger passenger = new Passenger();

        Passenger passenger1 = null;
	    if(userId!=null)
        {
            passenger.setUserId(userId);
            passenger.setEmail(email);
            passenger.setFirstname(name.split(" ")[0]);
            passenger.setLastname(name.split(" ")[1]);
            passenger.setPassword("");
            passenger1 = passengerRepository.save(passenger);
        }


	    return passenger1;

    }

    @Override
    public JSONObject cancelTrain(String trainId, String trainDate) throws ParseException {

	    //fetching all bookings

        SimpleDateFormat sm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = sm.parse(trainDate);

        //Section section = sectionRepository.findByTrainAvailability(date, trainId);

//        Ticket ticket = null;
//        if(section!=null)
//            ticket = section.getTicket();
//
//
//        int ticketId = ticket.getId();

       /* JSONObject response = cancelTicket(ticketId);

        if(response.get("status").equals("Inactive"))
        {
            //now book for the same passenger for next available trains

            BookingService bookingService = new BookingServiceImpl();
            BookingRequest bookingRequest = new BookingRequest();




            bookingService.book()
        }
*/




        return null;
    }

    @Override
    public Passenger updatePassenger(Passenger passenger) {

	    Passenger updatedPassenger = null;
	    if(passenger!=null)
        {
            updatedPassenger = passengerRepository.save(passenger);
        }
        return updatedPassenger;
    }

    @Override
    public JSONObject cancelTicket(int id) {

	    Booking booking =  bookingRepository.findById(id);

	    JSONObject response = new JSONObject();

	    if(booking!=null)
        {
            if(booking.getStatus().equals("Active"))
            {
                List<Ticket> ticketList = booking.getTicketList();
                List<Section> sectionList = new ArrayList<>();
                for (Ticket ticket :
                        ticketList ) {
                    sectionList = ticket.getSectionList();
                    for (Section section :
                            sectionList) {
                        TrainAvailability availableTrain = section.getTrainAvailability();
                        TrainAvailability updatedTrain = updateTrainAvailability(availableTrain,section.getOrigination(),section.getDestination());
                    }
                }
                booking.setStatus("Inactive");
                Booking updatedBooking = bookingRepository.save(booking);
    
                booking = bookingRepository.findOne(id);
                
                if (enableEmail) {
                    String emailContent = TrainUtils.getCancellationConfirmationEmailContent(booking);
        
                    emailService.sendEmail(booking.getPassenger().getEmail(), "Cancellation Confirmation From CUSR: " + booking.getId(), emailContent);
                }
                
                if(updatedBooking!=null)
                {
                    response.put("bookingId" , booking.getId());
                    response.put("status", booking.getStatus());
                }
                else
                {
                    response.put("error" , "Booking can't be canceled at this moment");
                }

            }
            else
                response.put("error", "Booking already cancelled");
        }
        else
            response.put("error", "Booking doesn't exist");

	    return  response;
    }


    public TrainAvailability updateTrainAvailability(TrainAvailability availableTrain, String origin, String destination)
    {
        int originValue = 0;
        int destinationValue = 0;
        if(origin.equals("A"))
        {
            originValue = availableTrain.getA();
            availableTrain.setA(originValue+1);
        }
        if(origin.equals("B"))
        {
            originValue = availableTrain.getB();
            availableTrain.setB(originValue+1);
        }
        if(origin.equals("C"))
        {
            originValue = availableTrain.getC();
            availableTrain.setC(originValue+1);
        }
        if(origin.equals("D"))
        {
            originValue = availableTrain.getD();
            availableTrain.setD(originValue+1);
        }
        if(origin.equals("E"))
        {
            originValue = availableTrain.getE();
            availableTrain.setE(originValue+1);
        }
        if(origin.equals("F"))
        {
            originValue = availableTrain.getF();
            availableTrain.setF(originValue+1);
        }
        if(origin.equals("G"))
        {
            originValue = availableTrain.getG();
            availableTrain.setG(originValue+1);
        }
        if(origin.equals("H"))
        {
            originValue = availableTrain.getH();
            availableTrain.setH(originValue+1);
        }
        if(origin.equals("I"))
        {
            originValue = availableTrain.getI();
            availableTrain.setI(originValue+1);
        }
        if(origin.equals("J"))
        {
            originValue = availableTrain.getJ();
            availableTrain.setJ(originValue+1);
        }
        if(origin.equals("K"))
        {
            originValue = availableTrain.getK();
            availableTrain.setK(originValue+1);
        }
        if(origin.equals("L"))
        {
            originValue = availableTrain.getL();
            availableTrain.setL(originValue+1);
        }
        if(origin.equals("M"))
        {
            originValue = availableTrain.getM();
            availableTrain.setM(originValue+1);
        }
        if(origin.equals("N"))
        {
            originValue = availableTrain.getN();
            availableTrain.setN(originValue+1);
        }
        if(origin.equals("O"))
        {
            originValue = availableTrain.getO();
            availableTrain.setO(originValue+1);
        }
        if(origin.equals("P"))
        {
            originValue = availableTrain.getP();
            availableTrain.setP(originValue+1);
        }
        if(origin.equals("Q"))
        {
            originValue = availableTrain.getQ();
            availableTrain.setQ(originValue+1);
        }
        if(origin.equals("R"))
        {
            originValue = availableTrain.getR();
            availableTrain.setR(originValue+1);
        }
        if(origin.equals("S"))
        {
            originValue = availableTrain.getS();
            availableTrain.setS(originValue+1);
        }
        if(origin.equals("T"))
        {
            originValue = availableTrain.getT();
            availableTrain.setT(originValue+1);
        }
        if(origin.equals("U"))
        {
            originValue = availableTrain.getU();
            availableTrain.setU(originValue+1);
        }
        if(origin.equals("V"))
        {
            originValue = availableTrain.getV();
            availableTrain.setV(originValue+1);
        }
        if(origin.equals("W"))
        {
            originValue = availableTrain.getW();
            availableTrain.setW(originValue+1);
        }
        if(origin.equals("X"))
        {
            originValue = availableTrain.getX();
            availableTrain.setX(originValue+1);
        }
        if(origin.equals("Y"))
        {
            originValue = availableTrain.getY();
            availableTrain.setY(originValue+1);
        }
        if(origin.equals("Z"))
        {
            originValue = availableTrain.getZ();
            availableTrain.setZ(originValue+1);
        }


        if(destination.equals("A"))
        {
            destinationValue = availableTrain.getA();
            availableTrain.setA(destinationValue+1);
        }
        if(destination.equals("B"))
        {
            destinationValue = availableTrain.getB();
            availableTrain.setB(destinationValue+1);
        }
        if(destination.equals("C"))
        {
            destinationValue = availableTrain.getC();
            availableTrain.setC(destinationValue+1);
        }
        if(destination.equals("D"))
        {
            destinationValue = availableTrain.getD();
            availableTrain.setD(destinationValue+1);
        }
        if(destination.equals("E"))
        {
            destinationValue = availableTrain.getE();
            availableTrain.setE(destinationValue+1);
        }
        if(destination.equals("F"))
        {
            destinationValue = availableTrain.getF();
            availableTrain.setF(destinationValue+1);
        }
        if(destination.equals("G"))
        {
            destinationValue = availableTrain.getG();
            availableTrain.setG(destinationValue+1);
        }
        if(destination.equals("H"))
        {
            destinationValue = availableTrain.getH();
            availableTrain.setH(destinationValue+1);
        }
        if(destination.equals("I"))
        {
            destinationValue = availableTrain.getI();
            availableTrain.setI(destinationValue+1);
        }
        if(destination.equals("J"))
        {
            destinationValue = availableTrain.getJ();
            availableTrain.setJ(destinationValue+1);
        }
        if(destination.equals("K"))
        {
            destinationValue = availableTrain.getK();
            availableTrain.setK(destinationValue+1);
        }
        if(destination.equals("L"))
        {
            destinationValue = availableTrain.getL();
            availableTrain.setL(destinationValue+1);
        }
        if(destination.equals("M"))
        {
            destinationValue = availableTrain.getM();
            availableTrain.setM(destinationValue+1);
        }
        if(destination.equals("N"))
        {
            destinationValue = availableTrain.getN();
            availableTrain.setN(destinationValue+1);
        }
        if(destination.equals("O"))
        {
            destinationValue = availableTrain.getO();
            availableTrain.setO(destinationValue+1);
        }
        if(destination.equals("P"))
        {
            destinationValue = availableTrain.getP();
            availableTrain.setP(destinationValue+1);
        }
        if(destination.equals("Q"))
        {
            destinationValue = availableTrain.getQ();
            availableTrain.setQ(destinationValue+1);
        }
        if(destination.equals("R"))
        {
            destinationValue = availableTrain.getR();
            availableTrain.setR(destinationValue+1);
        }
        if(destination.equals("S"))
        {
            destinationValue = availableTrain.getS();
            availableTrain.setS(destinationValue+1);
        }
        if(destination.equals("T"))
        {
            destinationValue = availableTrain.getT();
            availableTrain.setT(destinationValue+1);
        }
        if(destination.equals("U"))
        {
            destinationValue = availableTrain.getU();
            availableTrain.setU(destinationValue+1);
        }
        if(destination.equals("V"))
        {
            destinationValue = availableTrain.getV();
            availableTrain.setV(destinationValue+1);
        }
        if(destination.equals("W"))
        {
            destinationValue = availableTrain.getW();
            availableTrain.setW(destinationValue+1);
        }
        if(destination.equals("X"))
        {
            destinationValue = availableTrain.getX();
            availableTrain.setX(destinationValue+1);
        }
        if(destination.equals("Y"))
        {
            destinationValue = availableTrain.getY();
            availableTrain.setY(destinationValue+1);
        }
        if(destination.equals("Z"))
        {
            destinationValue = availableTrain.getZ();
            availableTrain.setZ(destinationValue+1);
        }

        return trainAvailabilityRepository.save(availableTrain);

    }
}
