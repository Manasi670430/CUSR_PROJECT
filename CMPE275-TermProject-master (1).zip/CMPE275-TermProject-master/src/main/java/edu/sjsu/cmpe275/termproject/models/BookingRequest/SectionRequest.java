package edu.sjsu.cmpe275.termproject.models.BookingRequest;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SectionRequest {
	private String origination;
	private String destination;
	private String trainId;
	private Date date;
	
	public SectionRequest(String origination, String destination, String trainId, Date date) {
		this.origination = origination;
		this.destination = destination;
		this.trainId = trainId;
		this.date = date;
	}
	
	/** Getters **/
	public String getOrigination() {
		return origination;
	}
	
	public String getDestination() {
		return destination;
	}
	
	public String getTrainId() {
		return trainId;
	}
	
	@JsonIgnore
	public Date getDate() {
		return date;
	}
	
	@JsonGetter("date")
	public String getDateString() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateTime = dateFormat.format(date);
		return dateTime;
	}
}
