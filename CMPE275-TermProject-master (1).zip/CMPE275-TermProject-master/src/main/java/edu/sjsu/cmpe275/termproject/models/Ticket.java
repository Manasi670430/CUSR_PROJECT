package edu.sjsu.cmpe275.termproject.models;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.*;
import java.util.List;

@Entity
public class Ticket {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private float price;
	
	@ManyToOne
	@JoinColumn(name = "bookingId")
	@JsonBackReference
	private Booking booking;

	@OneToMany(mappedBy = "ticket")
	@JsonManagedReference
	private List<Section> sectionList;
	
	private String origination;
	
	private String destination;
	
	// Constructor for JPA
	protected Ticket() {}
	
	public Ticket(Booking booking, float price, String origination, String destination) {
		this.booking = booking;
		this.price = price;
		this.origination = origination;
		this.destination = destination;
	}
	
	public int getId() {
		return id;
	}
	
	public Booking getBooking() {
		return booking;
	}
	
	public float getPrice() {
		float totalPrice = 0;
		for (Section section: this.sectionList) {
			totalPrice += section.getPrice();
		}
		return totalPrice;
	}
	
	public String getOrigination() {
		return origination;
	}
	
	public String getDestination() {
		return destination;
	}

	public String getDepartureTime() {
		return this.getSectionList().get(0).getDepartureTime();
	}

	public List<Section> getSectionList() {
		return sectionList;
	}
	
	public String getArrivalTime() {
		return this.getSectionList().get(this.getSectionList().size() - 1).getArrivalTime();
	}
	
}