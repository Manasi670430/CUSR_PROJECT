package edu.sjsu.cmpe275.termproject.services;


import edu.sjsu.cmpe275.termproject.models.Booking;
import edu.sjsu.cmpe275.termproject.models.BookingRequest.BookingRequest;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.sql.SQLException;

public interface BookingService {
	Booking book(BookingRequest bookingRequest) throws SQLException;
	void resetBooking();
}
