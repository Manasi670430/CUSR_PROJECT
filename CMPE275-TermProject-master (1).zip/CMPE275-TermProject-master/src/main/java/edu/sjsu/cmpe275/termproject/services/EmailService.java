package edu.sjsu.cmpe275.termproject.services;

public interface EmailService {
	void sendEmail(String recipient, String subject, Object content);
}
