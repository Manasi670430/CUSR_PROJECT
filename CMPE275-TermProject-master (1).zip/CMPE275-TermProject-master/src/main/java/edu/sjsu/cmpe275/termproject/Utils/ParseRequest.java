package edu.sjsu.cmpe275.termproject.Utils;

import edu.sjsu.cmpe275.termproject.models.BookingRequest.BookingRequest;
import edu.sjsu.cmpe275.termproject.models.BookingRequest.SectionRequest;
import edu.sjsu.cmpe275.termproject.models.BookingRequest.TicketRequest;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class ParseRequest {
	
	static DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	/**
	 * (Mock) Parse booking request string to BookingRequest class
	 * @param request
	 * @return
	 */
	public static BookingRequest parseBookingRequestMock(String request) {
		
		// Create section requests
		String origination1 = "A";
		String destination1 = "F";
		String trainId1 = "SB600";
		java.sql.Timestamp date1 = java.sql.Timestamp.valueOf("2017-12-01 06:00:00");
		
		String origination2 = "F";
		String destination2 = "G";
		String trainId2 = "SB615";
		java.sql.Timestamp date2 = java.sql.Timestamp.valueOf("2017-12-01 06:15:00");
		
		String origination3 = "G";
		String destination3 = "F";
		String trainId3 = "NB845";
		java.sql.Timestamp date3 = java.sql.Timestamp.valueOf("2017-12-01 08:45:00");
		
		String origination4 = "F";
		String destination4 = "A";
		String trainId4 = "NB2100";
		java.sql.Timestamp date4 = java.sql.Timestamp.valueOf("2017-12-01 21:00:00");
		
		SectionRequest sectionRequest1 = new SectionRequest(origination1, destination1, trainId1, date1);
		SectionRequest sectionRequest2 = new SectionRequest(origination2, destination2, trainId2, date2);
		SectionRequest sectionRequest3 = new SectionRequest(origination3, destination3, trainId3, date3);
		SectionRequest sectionRequest4 = new SectionRequest(origination4, destination4, trainId4, date4);
		
		// Create ticket requests
		TicketRequest ticketRequest1 = new TicketRequest(origination1, destination2);
		TicketRequest ticketRequest2 = new TicketRequest(origination3, destination4);
		
		ticketRequest1.addSectionRequest(sectionRequest1);
		ticketRequest1.addSectionRequest(sectionRequest2);
		ticketRequest2.addSectionRequest(sectionRequest3);
		ticketRequest2.addSectionRequest(sectionRequest4);
		
		// Create booking request
		String passengerId = "cIOjVqOMxaXstXM8LMs3c5KXby12";
		int numberOfPassengers = 10;
		boolean isRoundTrip = true;
		BookingRequest bookingRequest = new BookingRequest(passengerId, isRoundTrip, numberOfPassengers);
		bookingRequest.addTicketRequest(ticketRequest1);
		bookingRequest.addTicketRequest(ticketRequest2);
		
		return bookingRequest;
	}

	/**
	 * @param request
	 * @return
	 */
	public static BookingRequest parseBookingRequest(String request) {

		// Parse booking request
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject;
		BookingRequest bookingRequest;
		
//		System.out.println("booking request in json =======" + request);
		try{
			jsonObject = (JSONObject) jsonParser.parse(request);
			
			bookingRequest = new BookingRequest(
				(String) jsonObject.get("passengerId"),
				(Boolean) jsonObject.get("roundTrip"),
				((Long) jsonObject.get("numberOfPassengers")).intValue()
			);
			
			float totalcost = ((Long) jsonObject.get("totalcost")).floatValue();
			
			// An array of Tickets
			JSONArray ticketArray = (JSONArray) jsonObject.get("ticketRequestList");
			Iterator ticketArrayIterator  = ticketArray.iterator();
			
			while (ticketArrayIterator.hasNext()) {
				// Ticket
				TicketRequest ticketRequest = new TicketRequest();
				JSONObject ticketJson = (JSONObject) ticketArrayIterator.next();
				String origination = null;
				String destination = null;
				
				// An array of Sections
				JSONArray sectionArray = (JSONArray) ticketJson.get("sectionRequestList");
				Iterator sectionArrayIterator  = sectionArray.iterator();
				
				while (sectionArrayIterator.hasNext()) {
					// Section
					JSONObject sectionJson = (JSONObject) sectionArrayIterator.next();
					
					if (origination == null) { origination = (String) sectionJson.get("origination"); }
					destination = (String) sectionJson.get("destination");

					SectionRequest sectionRequest = new SectionRequest(
						(String) sectionJson.get("origination"),
						(String) sectionJson.get("destination"),
						(String) sectionJson.get("trainId"),
						java.sql.Timestamp.valueOf((String) sectionJson.get("date"))
					);
					
					ticketRequest.setOrigination(origination);
					ticketRequest.setDestination(destination);
					ticketRequest.addSectionRequest(sectionRequest);
				}
				
				bookingRequest.addTicketRequest(ticketRequest);
			}
			
			return bookingRequest;
			
		} catch(ParseException e) {
			
			e.printStackTrace();
			
			return null;
		}
		
	}
	
	private static List<TicketRequest> parseTicketRequest(String request) {
		return null;
	}
	
	private static List<SectionRequest> parseSectionRequest(String request) {
		return null;
	}
}
