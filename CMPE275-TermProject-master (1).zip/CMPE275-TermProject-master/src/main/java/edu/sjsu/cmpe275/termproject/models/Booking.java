package edu.sjsu.cmpe275.termproject.models;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;


import javax.persistence.*;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

@Entity
public class Booking {
	
	static final float TRANSACTION_FEE = 1;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private String status;
	
	private boolean isRoundTrip;
	
	@Column(insertable = false)
	private java.sql.Timestamp createdAt;
	
	@ManyToOne
	@JoinColumn(name = "passengerId")
	@JsonBackReference
	private Passenger passenger;
	
	@Column(name = "numberOfPassengers")
	private int numberOfPassengers;

    @OneToMany(mappedBy = "booking",fetch = FetchType.EAGER)
	@JsonManagedReference
	private List<Ticket> ticketList;
	
	
	// Constructor for JPA
	protected Booking() {
	
	}
	
	/**
	 * The initial state of a Booking is "Active"
	 * @param isRoundTrip
	 * @param passenger
	 */
	public Booking(boolean isRoundTrip, Passenger passenger, int numberOfPasssenters) {
		this.isRoundTrip = isRoundTrip;
		this.passenger = passenger;
		this.status = "Active";
		this.numberOfPassengers = numberOfPasssenters;
	}
	
	/** Getters **/
	/**
	 * @return Booking id
	 */
	public int getId() {
		return id;
	}
	
	public boolean isRoundTrip() {
		return isRoundTrip;
	}

	public Passenger getPassenger() {
		return passenger;
	}
	
	public String getCreatedAt() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		dateFormat.setTimeZone(TimeZone.getTimeZone("GMT-16"));
		String dateTime = dateFormat.format(createdAt);
		return dateTime;
	}
	
	public int getNumberOfPassengers() {
		return this.numberOfPassengers;
	}
	
	/**
	 * @return User booking history, most recent ticket first
	 */
	public List<Ticket> getTicketList() {
		return ticketList;
	}
	
	public String getStatus() {
		return status;
	}
	
	/** Setters **/

	
    public void setNumberOfPassengers(int numberOfPassengers) {
        this.numberOfPassengers = numberOfPassengers;
    }
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	@Override
	public String toString() {
    	String content;
    	return new String();
	}
	
	public float getBookingTotalPrice() {
    	
    	float totalPrice = 0;
    	
    	for (Ticket ticket: ticketList) {
    	    totalPrice += ticket.getPrice();
	    }
	    
	    totalPrice *= numberOfPassengers;
    	
    	totalPrice += TRANSACTION_FEE;
    	
	    return totalPrice;
	}
}