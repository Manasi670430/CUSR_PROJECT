package edu.sjsu.cmpe275.termproject.dao;

import edu.sjsu.cmpe275.termproject.models.Section;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;


//public interface SectionRepository extends JpaRepository<Section, Integer> {}

import java.io.Serializable;
import java.util.List;

public interface SectionRepository extends JpaRepository<Section, Serializable> {

    public List<Section> findByTicket(int id);

}