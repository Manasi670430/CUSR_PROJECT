package edu.sjsu.cmpe275.termproject.models;

import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;

@Entity
public class Connection {

    @Id
    private int id;

    private String destination;

    private String origin;


    @ManyToOne
    @JoinColumns({
            @JoinColumn(name = "train_id", referencedColumnName = "train_id",updatable = false, insertable = false),
            @JoinColumn(name = "date", referencedColumnName = "date", updatable = false, insertable = false)
    })
    @JsonBackReference
    TrainAvailability trainAvailability;


    public TrainAvailability getTrainAvailability() {
        return trainAvailability;
    }

    public void setTrainAvailability(TrainAvailability trainAvailability) {
        this.trainAvailability = trainAvailability;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


}
