package edu.sjsu.cmpe275.termproject.dao;

import edu.sjsu.cmpe275.termproject.models.Train;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import java.io.Serializable;
import java.util.List;

public interface TrainRepository extends JpaRepository<Train, Serializable> {

    public List<Train> findByType(String type);

    public List<Train> findAll();




}