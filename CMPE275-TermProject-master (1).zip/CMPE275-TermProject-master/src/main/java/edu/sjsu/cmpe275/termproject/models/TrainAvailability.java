package edu.sjsu.cmpe275.termproject.models;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import org.springframework.data.jpa.repository.Temporal;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.*;
import java.util.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

@Entity
@IdClass(TrainAvailabilityId.class)
@Table(name = "TRAIN_AVAILABILITY")
public class TrainAvailability {
	//@Id
	//private java.sql.Date date;

	@Id
	private java.util.Date date;
	
	@Id
	@Column(name = "train_id")
	private String trainId;
	
	@ManyToOne
	@JoinColumn(name = "train_id", updatable = false, insertable = false)
	@JsonBackReference
	private Train train;
	
	@OneToMany(mappedBy = "trainAvailability")
	@JsonBackReference
	private List<Section> sectionList;


    @OneToMany(mappedBy = "trainAvailability")
    @JsonManagedReference
    @JsonIgnore
    private List<Connection> connections;

    @JsonIgnore
    public List<Connection> getConnections() {
        return connections;
    }

    public void setConnections(List<Connection> connections) {
        this.connections = connections;
    }

    private int A;
	private int B;
	private int C;
	private int D;
	private int E;
	private int F;
	private int G;
	private int H;
	private int I;
	private int J;
	private int K;
	private int L;
	private int M;
	private int N;
	private int O;
	private int P;
	private int Q;
	private int R;
	private int S;
	private int T;
	private int U;
	private int V;
	private int W;
	private int X;
	private int Y;
	private int Z;

    public void setA(int a) {
        A = a;
    }

    public void setB(int b) {
        B = b;
    }

    public void setC(int c) {
        C = c;
    }

    public void setD(int d) {
        D = d;
    }

    public void setE(int e) {
        E = e;
    }

    public void setF(int f) {
        F = f;
    }

    public void setG(int g) {
        G = g;
    }

    public void setH(int h) {
        H = h;
    }

    public void setI(int i) {
        I = i;
    }

    public void setJ(int j) {
        J = j;
    }

    public void setK(int k) {
        K = k;
    }

    public void setL(int l) {
        L = l;
    }

    public void setM(int m) {
        M = m;
    }

    public void setN(int n) {
        N = n;
    }

    public void setO(int o) {
        O = o;
    }

    public void setP(int p) {
        P = p;
    }

    public void setQ(int q) {
        Q = q;
    }

    public void setR(int r) {
        R = r;
    }

    public void setS(int s) {
        S = s;
    }

    public void setT(int t) {
        T = t;
    }

    public void setU(int u) {
        U = u;
    }

    public void setV(int v) {
        V = v;
    }

    public void setW(int w) {
        W = w;
    }

    public void setX(int x) {
        X = x;
    }

    public void setY(int y) {
        Y = y;
    }

    public void setZ(int z) {
        Z = z;
    }
	
    @JsonGetter("date")
	public String getDateString() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//		dateFormat.setTimeZone(TimeZone.getTimeZone("GMT-16"));
		String dateTime = dateFormat.format(date);
		return dateTime;
	}

	@Column(name = "date")
	@JsonIgnore
	public Date getDate() {
		return date;
	}
	
	
	public Train getTrain() {
		return train;
	}
	
	
	public String getTrainId() {
		return train.getId();
	}
	
	@JsonIgnore
	public int getA() {
		return A;
	}
	@JsonIgnore
	public int getB() {
		return B;
	}
	@JsonIgnore
	public int getC() {
		return C;
	}
	@JsonIgnore
	public int getD() {
		return D;
	}
	@JsonIgnore
	public int getE() {
		return E;
	}
	@JsonIgnore
	public int getF() {
		return F;
	}
	@JsonIgnore
	public int getG() {
		return G;
	}
	@JsonIgnore
	public int getH() {
		return H;
	}
	@JsonIgnore
	public int getI() {
		return I;
	}
	@JsonIgnore
	public int getJ() {
		return J;
	}
	@JsonIgnore
	public int getK() {
		return K;
	}
	@JsonIgnore
	public int getL() {
		return L;
	}
	@JsonIgnore
	public int getM() {
		return M;
	}
	@JsonIgnore
	public int getN() {
		return N;
	}
	@JsonIgnore
	public int getO() {
		return O;
	}
	@JsonIgnore
	public int getP() {
		return P;
	}
	@JsonIgnore
	public int getQ() {
		return Q;
	}
	@JsonIgnore
	public int getR() {
		return R;
	}
	@JsonIgnore
	public int getS() {
		return S;
	}
	@JsonIgnore
	public int getT() {
		return T;
	}
	@JsonIgnore
	public int getU() {
		return U;
	}
	@JsonIgnore
	public int getV() {
		return V;
	}
	@JsonIgnore
	public int getW() {
		return W;
	}
	@JsonIgnore
	public int getX() {
		return X;
	}
	@JsonIgnore
	public int getY() {
		return Y;
	}
	@JsonIgnore
	public int getZ() {
		return Z;
	}
	
	@JsonIgnore
	public List<Integer> getAvailability() {
		List<Integer> list = new ArrayList<>();
		list.add(A);
		list.add(B);
		list.add(C);
		list.add(D);
		list.add(E);
		list.add(F);
		list.add(G);
		list.add(H);
		list.add(I);
		list.add(J);
		list.add(K);
		list.add(L);
		list.add(M);
		list.add(N);
		list.add(O);
		list.add(P);
		list.add(Q);
		list.add(R);
		list.add(S);
		list.add(T);
		list.add(U);
		list.add(V);
		list.add(W);
		list.add(X);
		list.add(Y);
		list.add(Z);
		return list;
	}
}