package edu.sjsu.cmpe275.termproject.dao;

import edu.sjsu.cmpe275.termproject.models.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import java.io.Serializable;

//public interface BookingRepository extends JpaRepository<Booking, Integer> {
//}

import java.io.Serializable;
import java.lang.invoke.SerializedLambda;

public interface BookingRepository extends JpaRepository<Booking, Serializable> {

    public Booking findById(int id);
}