package edu.sjsu.cmpe275.termproject.models;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import edu.sjsu.cmpe275.termproject.Utils.TrainUtils;

import javax.persistence.*;

@Entity
public class Section {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name = "train_id", referencedColumnName = "train_id"),
		@JoinColumn(name = "date", referencedColumnName = "date")
	})
	@JsonManagedReference
	TrainAvailability trainAvailability;
	
	private String origination;
	
	private String destination;
	
	@ManyToOne
	@JoinColumn(name = "ticket_id")
	@JsonBackReference
	private Ticket ticket;
	
	protected Section() {}
	
	public Section(String origination, String destination, Ticket ticket, TrainAvailability trainAvailability) {
		this.origination = origination;
		this.destination = destination;
		this.ticket = ticket;
		this.trainAvailability = trainAvailability;
	}
	
	public int getId() {
		return id;
	}
	
	public String getOrigination() {
		return origination;
	}
	
	public String getDestination() {
		return destination;
	}
	
	public Ticket getTicket() {
		return ticket;
	}
	
	public String getDepartureTime() {
		return TrainUtils.calculateDepartureTime(
			origination,
			destination,
			trainAvailability.getTrainId(),
			trainAvailability.getTrain().getType(),
			trainAvailability.getDate());
	}
	
	public String getArrivalTime() {
		return TrainUtils.calculateArrivalTime(
			origination,
			destination,
			trainAvailability.getTrainId(),
			trainAvailability.getTrain().getType(),
			trainAvailability.getDate());
	}
	
	public float getPrice() {
		
		return TrainUtils.calculatePrice(
			origination,
			destination,
			trainAvailability.getTrainId(),
			trainAvailability.getTrain().getType()
		);
	}
	
	public TrainAvailability getTrainAvailability() {
		return trainAvailability;
	}
}