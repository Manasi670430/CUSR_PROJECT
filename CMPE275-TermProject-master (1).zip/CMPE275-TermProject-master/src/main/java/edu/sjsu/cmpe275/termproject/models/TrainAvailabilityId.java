package edu.sjsu.cmpe275.termproject.models;

import javax.persistence.Embeddable;
import java.io.Serializable;

import java.sql.Date;
import java.sql.Timestamp;

//@Embeddable
public class TrainAvailabilityId implements Serializable{
	private String trainId;
	private java.util.Date date;
	
	protected TrainAvailabilityId() {}
	
	public TrainAvailabilityId (String trainId, java.util.Date date) {
		this.trainId = trainId;
		this.date = date;
	}
	
	public String getTrainId() {
		return trainId;
	}
	
	public java.util.Date getDate() {
		return date;
	}
	
	@Override
	public boolean equals(Object o) {
		if (o == this) return true;
		if (!(o instanceof TrainAvailability)) {
			return false;
		}
		
		TrainAvailability trainAvailability = (TrainAvailability) o;
		
		return trainAvailability.getTrainId().equals(trainId) &&
			trainAvailability.getDate().equals(date);
	}
	
	@Override
	public int hashCode() {
		int result = 17;
		result = 31 * result + trainId.hashCode();
		result = 31 * result + date.hashCode();
		return result;
	}
}