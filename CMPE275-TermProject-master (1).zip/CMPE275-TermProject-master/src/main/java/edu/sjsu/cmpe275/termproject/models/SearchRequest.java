/**
 * 
 */
package edu.sjsu.cmpe275.termproject.models;

import org.springframework.stereotype.Component;

/**
 * @author Abhishek
 *
 */
@Component
public class SearchRequest {
	
	private String origin;
	private String destination;
	private String departureTime;
	private String returnTime;
	private String trainType;
	private int numberOfPassengers;
	private boolean isRoundTrip;
	private boolean isExactTime;


	private int numberOfConnections;
	/**
	 *@return the origin
	 **/
	public String getOrigin() {
		return origin;
	}
	/**
	 * @param origin the origin to set
	 */
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	/**
	 * @return the destination
	 */
	public String getDestination() {
		return destination;
	}
	/**
	 * @param destination the destination to set
	 */
	public void setDestination(String destination) {
		this.destination = destination;
	}
	/**
	 * @return the departureTime
	 */
	public String getDepartureTime() {
		return departureTime;
	}
	/**
	 * @param departureTime the departureTime to set
	 */
	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}
	/**
	 * @return the returnTime
	 */
	public String getReturnTime() {
		return returnTime;
	}
	/**
	 * @param returnTime the returnTime to set
	 */
	public void setReturnTime(String returnTime) {
		this.returnTime = returnTime;
	}
	/**
	 * @return the trainType
	 */
	public String getTrainType() {
		return trainType;
	}
	/**
	 * @param trainType the trainType to set
	 */
	public void setTrainType(String trainType) {
		this.trainType = trainType;
	}
	/**
	 * @return the isRoundTrip
	 */
	public boolean isRoundTrip() {
		return isRoundTrip;
	}
	/**
	 * @param isRoundTrip the isRoundTrip to set
	 */
	public void setRoundTrip(boolean isRoundTrip) {
		this.isRoundTrip = isRoundTrip;
	}

	public int getNumberOfPassengers() {
		return numberOfPassengers;
	}

	public void setNumberOfPassengers(int numberOfPassengers) {
		this.numberOfPassengers = numberOfPassengers;
	}

	public int getNumberOfConnections() {
		return numberOfConnections;
	}

	public void setNumberOfConnections(int numberOfConnections) {
		this.numberOfConnections = numberOfConnections;
	}

	public boolean isExactTime() {
		return isExactTime;
	}

	public void setExactTime(boolean exactTime) {
		isExactTime = exactTime;
	}
}
