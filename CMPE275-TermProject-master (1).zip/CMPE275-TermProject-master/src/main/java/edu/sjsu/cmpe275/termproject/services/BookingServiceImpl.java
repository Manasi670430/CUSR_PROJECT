package edu.sjsu.cmpe275.termproject.services;

import edu.sjsu.cmpe275.termproject.Utils.TrainUtils;
import edu.sjsu.cmpe275.termproject.dao.*;
import edu.sjsu.cmpe275.termproject.models.*;
import edu.sjsu.cmpe275.termproject.models.BookingRequest.BookingRequest;
import edu.sjsu.cmpe275.termproject.models.BookingRequest.SectionRequest;
import edu.sjsu.cmpe275.termproject.models.BookingRequest.TicketRequest;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service("bookingServiceImpl")
public class BookingServiceImpl implements BookingService{
	
	private boolean enableEmail = true;
	
	private DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	@Autowired
	BookingRepository bookingRepository;
	
	@Autowired
	TicketRepository ticketRepository;
	
	@Autowired
	SectionRepository sectionRepository;
	
	@Autowired
	TrainAvailabilityRepository trainAvailabilityRepository;
	
	@Autowired
	PassengerRepository passengerRepository;
	
	@Autowired
	EmailService emailService;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	@Transactional(rollbackFor = {SQLException.class})
	public Booking book(BookingRequest bookingRequest) throws SQLException{
		
		TrainUtils.setEntityManager(entityManager);
		
		// Persist Booking
		int numberOfPassengers = bookingRequest.getNumberOfPassengers();
		Passenger passenger = passengerRepository.findOne(bookingRequest.getPassengerId()); // find by passengerId
		
		Booking booking = new Booking(bookingRequest.isRoundTrip(), passenger, numberOfPassengers);
		bookingRepository.saveAndFlush(booking);
		entityManager.clear();                          // Clear cache
		int bookingId = booking.getId();
		booking = bookingRepository.findOne(bookingId);
		
		// Create Ticket record in database: Transactional
		for (TicketRequest ticketRequest: bookingRequest.getTicketRequestList()) {
			createTicket(booking, ticketRequest, bookingId);
		}
		
		booking = bookingRepository.findOne(bookingId);
		
		// Email switch
		if (enableEmail) {
			String emailContent = TrainUtils.getBookingConfirmationEmailContent(booking);
			
			emailService.sendEmail(booking.getPassenger().getEmail(), "Booking Confirmation From CUSR: " + booking.getId(), emailContent);
		}
		
		return booking;
	}
	
	@Transactional(propagation = Propagation.MANDATORY)
	public void createTicket(Booking booking, TicketRequest ticketRequest, int bookindId) {
		
		float price = 1;
		String origination = ticketRequest.getOrigination();
		String destination = ticketRequest.getDestination();
		
		// Persist Ticket
		Ticket ticket = new Ticket(booking, price, origination, destination);
		
		ticketRepository.saveAndFlush(ticket);
		entityManager.clear();
		
		int ticketId = ticket.getId();
		ticket = ticketRepository.findOne(ticketId);
		
		// Persist Sections
		for (SectionRequest sectionRequest: ticketRequest.getSectionRequestList()) {
			createSection(ticket, sectionRequest, ticketId);
		}
	}
	
	@Transactional(propagation = Propagation.MANDATORY)
	public void createSection(Ticket ticket, SectionRequest sectionRequest, int ticketId) {
		
		String trainId = sectionRequest.getTrainId();
		
		Date date = sectionRequest.getDate();
	

		TrainAvailabilityId trainAvailabilityId = new TrainAvailabilityId(trainId, date);
		TrainAvailability trainAvailability = trainAvailabilityRepository.findOne(trainAvailabilityId);
		
		String origination = sectionRequest.getOrigination();
		String destination = sectionRequest.getDestination();
		
		// Persist section
		Section section = new Section(origination, destination, ticket, trainAvailability);
		sectionRepository.saveAndFlush(section);
		int sectionId = section.getId();
		entityManager.clear();
		section = sectionRepository.findOne(sectionId);
		
		// Modify availability
		decreaseTrainAvailability(trainAvailability, origination, destination, ticket.getBooking().getNumberOfPassengers());
	}
	
	@Transactional(propagation = Propagation.MANDATORY)
	public void decreaseTrainAvailability(TrainAvailability trainAvailability, String origination, String destination, int numberOfPassengers) {
		
		Query query = TrainUtils.queryGenerator(
			origination,
			destination,
			trainAvailability.getTrainId(),
			trainAvailability.getDate().toString(),
			numberOfPassengers,
			trainAvailability.getAvailability());
		query.executeUpdate();
	}
	
	
	/**
	 * Delete all Bookings & Tickets & Sections
	 */
	@Transactional
	public void resetBooking() {
		bookingRepository.deleteAll();
		entityManager
			.createNativeQuery("ALTER TABLE CMPE275.Booking AUTO_INCREMENT = 1;")
			.executeUpdate();
		entityManager.flush();
	}
	
	@Transactional
	public void resetTrainAvailability(String dateString, int quantity, int nDays) {
		
		Date date;
		
		TrainUtils.setEntityManager(entityManager);
		
		try {
			
			date = dateFormat.parse(dateString);
			
			Query query = TrainUtils.getResetTrainAvailabilityQuery(date, quantity, nDays);
			
			query.executeUpdate();
			
		} catch(ParseException e) { e.printStackTrace(); }
		
	}
}
