package edu.sjsu.cmpe275.termproject.controller;

//import edu.sjsu.cmpe275.termproject.ErrorMessage.ErrorMessage;
import edu.sjsu.cmpe275.termproject.Utils.ParseRequest;
import edu.sjsu.cmpe275.termproject.Utils.TrainUtils;
import edu.sjsu.cmpe275.termproject.dao.*;
import edu.sjsu.cmpe275.termproject.models.*;
import edu.sjsu.cmpe275.termproject.models.BookingRequest.BookingRequest;
import edu.sjsu.cmpe275.termproject.services.BookingService;
import edu.sjsu.cmpe275.termproject.services.BookingServiceImpl;
import edu.sjsu.cmpe275.termproject.services.EmailService;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.json.JacksonJsonParser;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.sql.SQLException;
//import java.text.ParseException;
import org.json.simple.parser.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@RestController
@RequestMapping("/user/*")
public class BookingController {
	
	@Autowired
	PassengerRepository passengerRepository;
	
	@Autowired
	TrainRepository trainRepository;
	
	@Autowired
	TrainAvailabilityRepository trainAvailabilityRepository;
	
	@Autowired
	BookingRepository bookingRepository;
	
	@Autowired
	TicketRepository ticketRepository;
	
	@Autowired
	BookingServiceImpl bookingServiceImpl;
	
	@Autowired
	EmailService emailService;
	
	private static JacksonJsonParser jacksonJsonParser = new JacksonJsonParser();
	
	/**
	 * Find a booking by bookingId
	 * @param bookingId
	 * @return Booking Object in Json format
	 */
	@GetMapping("booking/{bookingId}")
	public ResponseEntity<Object> getBooking(@PathVariable int bookingId) {
		
		Booking booking = bookingRepository.findOne(bookingId);
		
		return new ResponseEntity<>(booking, HttpStatus.OK);
	}
	
	/**
	 * Make a booking.
	 * @param jsonRequestBody
	 * @return
	 */
	@RequestMapping(value="/booking", method=RequestMethod.POST,  consumes="application/json")
	public ResponseEntity<Object> postBooking(@RequestBody String jsonRequestBody) {
		
		BookingRequest bookingRequest = ParseRequest.parseBookingRequest(jsonRequestBody);
		
		Booking booking = null;
		
		try {
			booking = bookingServiceImpl.book(bookingRequest);
			
			booking = bookingRepository.findOne(booking.getId());
			
			return new ResponseEntity<>(booking, HttpStatus.OK);
			
		} catch (SQLException e) {
			return new ResponseEntity<>("Transaction cancelled", HttpStatus.OK);
		}
		
	}
	
	@PostMapping("booking_test")
	public ResponseEntity<Object> postBookingTest(@RequestBody String jsonRequestBody) {
		
		return new ResponseEntity<Object>(ParseRequest.parseBookingRequest(jsonRequestBody), HttpStatus.OK);
		
	}
	
	
	@GetMapping("bookingHistory/{userId}")
	public ResponseEntity<Object> getBookingHistory(@PathVariable String userId) {

		Passenger passenger = passengerRepository.findByUserId(userId);
		
		passenger.getBookingList().sort(Comparator.comparingInt(Booking::getId).reversed());
		
		return new ResponseEntity<>(passenger.getBookingList(), HttpStatus.OK);
	}

	
	@DeleteMapping("reset")
	public ResponseEntity<Object> resetBookings() {
		
		bookingServiceImpl.resetBooking();
		
		return new ResponseEntity<>("All bookings has been deleted", HttpStatus.OK);
		
	}
	
	@GetMapping("ticket")
	public ResponseEntity<Object> getTicket() {
		
		Ticket ticket = ticketRepository.findOne(1);
		
		return new ResponseEntity<>(ticket, HttpStatus.OK);
	}
	
	@GetMapping("section")
	public ResponseEntity<Object> getSection() {
		
		return new ResponseEntity<>("section", HttpStatus.OK);
	}
	
	@GetMapping("email")
	public ResponseEntity<Object> testEmailNotification() {
		
		emailService.sendEmail("lb8166@gmail.com", "test", "Hello cusr");
		
		return new ResponseEntity<>("section", HttpStatus.OK);
	}
	
	@PostMapping("/searching")
	public JSONObject getTrain(@RequestBody SearchRequest request) {
		
		return null;
	}
	
	@PostMapping("/reset_train_availability")
	public ResponseEntity<Object> resetTrainAvailability(@RequestBody String requestBody) {
		
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject;
		
		try {
			jsonObject = (JSONObject) jsonParser.parse(requestBody);
			
			String startDate = "2017-12-20 06:00:00";
			
			long quantity = (Long) jsonObject.get("quantity");
			
			long nDays = (Long) jsonObject.get("days");
			
			bookingServiceImpl.resetTrainAvailability(startDate, (int)quantity, (int)nDays);
			
			return new ResponseEntity<>("Reset successful", HttpStatus.OK);
			
		} catch(ParseException e) {
			
			return new ResponseEntity<>("Reset failed. JSON parser error.", HttpStatus.BAD_REQUEST);
		}
		
	}
	
}