/**
 * 
 */
package edu.sjsu.cmpe275.termproject.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/************************************/
/** Use Passenger instead of User **/
/************************************/
/**
 * @author Abhishek
 *
 */
@Entity
@Table(name="USER")
public class User {

	@Id
	@Column(name="user_id")
	private String userId;
	
	@Column(name="user_email")
	private String userEmail;
	
	@Column(name="fullname")
	private String fullName;
	
	@Column(name="isPassenger")
	private boolean isPassenger;
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the fullName
	 */
	public String getFullName() {
		return fullName;
	}
	/**
	 * @param fullName the fullName to set
	 */
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	/**
	 * @return the isPassenger
	 */
	public boolean isPassenger() {
		return isPassenger;
	}
	/**
	 * @param isPassenger the isPassenger to set
	 */
	public void setPassenger(boolean isPassenger) {
		this.isPassenger = isPassenger;
	}
	/**
	 * @return the userEmail
	 */
	public String getUserEmail() {
		return userEmail;
	}
	/**
	 * @param userEmail the userEmail to set
	 */
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	
}
