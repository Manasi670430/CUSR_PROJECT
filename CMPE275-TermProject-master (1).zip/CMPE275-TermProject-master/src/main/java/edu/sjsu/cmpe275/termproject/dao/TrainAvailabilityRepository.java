package edu.sjsu.cmpe275.termproject.dao;

import edu.sjsu.cmpe275.termproject.models.TrainAvailability;
import edu.sjsu.cmpe275.termproject.models.TrainAvailabilityId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import java.io.Serializable;
import java.util.List;

public interface TrainAvailabilityRepository extends JpaRepository<TrainAvailability, Serializable>{

}