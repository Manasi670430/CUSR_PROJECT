package edu.sjsu.cmpe275.termproject.dao;

import edu.sjsu.cmpe275.termproject.models.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

//public interface TicketRepository extends JpaRepository<Ticket, Integer> {}

import java.io.Serializable;
import java.util.List;

public interface TicketRepository extends JpaRepository<Ticket, Serializable> {
        public List<Ticket> findByBooking(int id);

}