package edu.sjsu.cmpe275.termproject.dao;

import edu.sjsu.cmpe275.termproject.models.Passenger;
import org.springframework.data.jpa.repository.JpaRepository;

import java.io.Serializable;

public interface PassengerRepository extends JpaRepository<Passenger,Serializable>{

//    public Passenger findById(int id);

    public Passenger findByUserId(String userId);

    /**
     * @param email
     * @return Passenger that matches the given email
     */
    Passenger findPassengerByEmail(String email);
}
