package edu.sjsu.cmpe275.termproject.models;

import java.util.List;

public class BookingRequestJson {

//	{
//		"numberOfPassengers": 1,
//		"passengerId": "abc",
//		"isRoundTrip": true,
//		"totalcost" :2,
//		"ticketRequestList": [
//		{
//			"sectionRequestList": [
//			{
//				"origination": "A",
//				"destination": "B",
//				"trainId": "SB600",
//				"date": "2017-12-20",
//				"cost" : 1
//			},
//			{
//				"origination": "B",
//				"destination": "F",
//				"trainId": "SB615",
//				"date": "2017-12-20",
//				"cost" : 1
//			}
//            ]
//		}
//    ]
//	}
	
	private int numberOfPassengers;
	private int passengerId;
	private boolean isRoundTrip;
	private float totalcost;
	private List<Object> ticketRequestList;
	
}
