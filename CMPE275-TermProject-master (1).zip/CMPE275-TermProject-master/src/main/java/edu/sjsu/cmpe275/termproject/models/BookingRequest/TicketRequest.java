package edu.sjsu.cmpe275.termproject.models.BookingRequest;

import java.util.ArrayList;
import java.util.List;

public class TicketRequest {
	private String origination;
	private String destination;
	private List<SectionRequest> sectionRequestList;

	public TicketRequest() {
		sectionRequestList = new ArrayList<>();
	}
	
	public TicketRequest(String origination, String destination) {
		this.origination = origination;
		this.destination = destination;
		sectionRequestList = new ArrayList<>();
	}
	
	/** Getters **/
	public String getOrigination() {
		return origination;
	}
	
	public String getDestination() {
		return destination;
	}
	
	public List<SectionRequest> getSectionRequestList() {
		return sectionRequestList;
	}
	
	/** Setters **/
	public void setOrigination(String origination) {
		this.origination = origination;
	}
	
	public void setDestination(String destination) {
		this.destination = destination;
	}
	
	/**
	 * Add a new section to the ticket
	 * @param sectionRequest
	 */
	public void addSectionRequest(SectionRequest sectionRequest) {
		sectionRequestList.add(sectionRequest);
	}
}
