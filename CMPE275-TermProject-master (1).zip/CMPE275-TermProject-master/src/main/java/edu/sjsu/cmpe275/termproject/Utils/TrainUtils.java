package edu.sjsu.cmpe275.termproject.Utils;

import edu.sjsu.cmpe275.termproject.models.Booking;
import edu.sjsu.cmpe275.termproject.models.Passenger;
import edu.sjsu.cmpe275.termproject.models.Ticket;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.Query;
import javax.persistence.EntityManager;
import javax.swing.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class TrainUtils {
	
	private static DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	private static final int STOP_TIME = 3; // in minute
	private static final int TRAVEL_TIME = 5; // in minute
	private static Calendar calendar  = Calendar.getInstance();
	private static float REGULAR_FARE = 1;
	private static float EXPRESS_FARE = 2;
	
	@Autowired
	private static EntityManager entityManager;
	
	/**
	 * @param trainType
	 * @param origination
	 * @param destination
	 * @param departureTime
	 * @return arrival time in "yyyy-MM-dd HH:mm:ss format"
	 */
	public static String calculateArrivalTime(String trainType, String origination, String destination, String departureTime) {
		try {
			dateFormat.setTimeZone(TimeZone.getTimeZone("GMT-16"));
			Date date = dateFormat.parse(departureTime);
			int originInt = origination.toLowerCase().charAt(0) - 'a';
			int destInt = destination.toLowerCase().charAt(0) - 'a';
			int nStops = destInt - originInt;
			
			calendar.setTime(date);
			
			return trainType.toLowerCase().equals("regular") ?
				calculateArrivalTimeRegular(calendar, nStops) :
				calculateArrivalTimeExpress(calendar, nStops);
			
		} catch (ParseException e) {
			
			return "parse error";
		}
	}
	
	private static String calculateArrivalTimeRegular(Calendar calendar, int nStops) {
			
			long arrivalTimeMils =
				calendar.getTimeInMillis() +
				((nStops - 1) * (TRAVEL_TIME + STOP_TIME) + TRAVEL_TIME) * 60 * 1000;
			calendar.setTimeInMillis(arrivalTimeMils);
			return dateFormat.format(calendar.getTime());
	}
	
	private static String calculateArrivalTimeExpress(Calendar calendar, int nStops) {
		long arrivalTimeMils =
			calendar.getTimeInMillis() +
			(nStops * TRAVEL_TIME + (nStops / 5 - 1) * STOP_TIME) * 60 * 1000;
		calendar.setTimeInMillis(arrivalTimeMils);
		
		return dateFormat.format(calendar.getTime());
	}
	
	/**
	 * @param origination
	 * @param destination
	 * @param numberOfPassengers
	 * @return Decrease train availability query
	 */
	public static Query queryGenerator(String origination, String destination, String trainId, String date, int numberOfPassengers, List<Integer> list) {
		
		char originChar = origination.toUpperCase().charAt(0);
		char destChar = destination.toUpperCase().charAt(0);
		
		String sql =
			"UPDATE TRAIN_AVAILABILITY" +
				" SET ";
		
		if (trainId.toUpperCase().contains("SB")) {
			for (char i = originChar; i < destChar; i++) {
				sql += String.valueOf(i) + "=?";
				sql += i == destChar - 1 ? " " : ", ";
				
			}
			
		} else {
			
			for (char i = destChar; i < originChar; i++) {
				sql += String.valueOf(i) + "=?";
				sql += i == originChar - 1 ? " " : ", ";
				
			}
		}
		
		sql += " WHERE train_id = ? AND date = ?";
		
		Query query = entityManager.createNativeQuery(sql);
//		System.out.println("TrainId++++++++++++++" + trainId);
//		System.out.println("query++++++++++++++" + sql);
		if (trainId.toUpperCase().contains("SB")) {
			for (char i = originChar; i < destChar; i++) {
//				System.out.println("==========" + i);
				query.setParameter(i - originChar + 1, list.get(i - 'A') - numberOfPassengers);
			}
			
			query.setParameter(destChar - originChar + 1, trainId);
			query.setParameter(destChar - originChar + 2, date);
			
		} else {
			
			for (char i = destChar; i < originChar; i++) {
//				if (trainId.equals("NB2100")) {
//					System.out.println("&&&&&&&&&&&&&&&&&&" + (list.get(i - 'A') - numberOfPassengers));
//				}
				
				query.setParameter(i - destChar + 1, list.get(i - 'A') - numberOfPassengers);
			}
			
			query.setParameter( originChar - destChar + 1, trainId);
			query.setParameter(originChar - destChar + 2, date);
		}
		
		return query;
	}
	
	public static String calculateDepartureTime(String origination, String destination, String trainId, String trainType, Date date) {
		
		calendar.setTime(date);
		
		int minutes = 0;
		
		trainId = trainId.toUpperCase();
		
		int nStops = trainId.contains("SB") ?
			origination.toUpperCase().charAt(0) - 'A' :
			'Z' - origination.toUpperCase().charAt(0);
		
		if (trainType.toUpperCase().equals("REGULAR")) {
			
			minutes = nStops * TRAVEL_TIME + (nStops > 0 ? nStops : 0) * STOP_TIME;
			
		} else { // express train
			
			minutes = nStops * TRAVEL_TIME + (nStops > 0 ? nStops / 5 : 0) * STOP_TIME;
			
		}
		
		calendar.add(Calendar.MINUTE, minutes);
		date = calendar.getTime();
		
		return dateFormat.format(date);
	}
	
	public static String calculateArrivalTime(String origination, String destination, String trainId, String trainType, Date date) {
		
		calendar.setTime(date);
		
		int minutes = 0;
		
		trainId = trainId.toUpperCase();
		
		int nStops = trainId.contains("SB") ?
			destination.toUpperCase().charAt(0) - 'A' :
			'Z' - destination.toUpperCase().charAt(0);
		
		if (trainType.toUpperCase().equals("REGULAR")) {
			
			minutes = nStops * TRAVEL_TIME + (nStops > 0 ? nStops : 0) * STOP_TIME;
			
		} else { // express train
			
			minutes = nStops * TRAVEL_TIME + (nStops > 0 ? nStops / 5 : 0) * STOP_TIME;
			
		}
		
		calendar.add(Calendar.MINUTE, minutes - STOP_TIME);
		date = calendar.getTime();
		
		return dateFormat.format(date);
	}
	
	public static void setEntityManager(EntityManager entityManager) {TrainUtils.entityManager = entityManager; }
	
	public static List<String> generateTrainIdList() {
		
		List<String> trainIdListSB = generateTrainIdHelper("SB");
		return trainIdListSB;
	}
	
	private static List<String> generateTrainIdHelper(String direction) {
		List<String> trainIdList = new ArrayList<>();
		
		int startTime = 600;
		int endTime = 2100;
		int time = startTime;
		
		while (time <= endTime) {
			trainIdList.add(direction + String.valueOf(time));
			
			time += 15;
			
			if (time % 100 == 60) {
				time -= time % 100;
				time += 100;
			}
		}
		
		return trainIdList;
	}
	
	public static List<String> generateTrainDepartureList(Date startDate) {
		
		List<String> trainDepartureList = new ArrayList<>();
		List<String> trainIdList = generateTrainIdHelper("SB");

		String dateString;

		calendar.setTime(startDate);
		
		for (String trainId: trainIdList) {
			dateString = dateFormat.format(calendar.getTime());
			trainDepartureList.add(dateString);
			calendar.add(Calendar.MINUTE, 15);
		}
		
		return trainDepartureList;
	}
	
	public static List<List<String>> getResetTrainAvailabilityQueryHelper (Date startDate, int quantity, int nDays) {
		
		List<List<String>> result = new ArrayList<List<String>>();
		
		List<String> trainIdList = new ArrayList<>();
		List<String> trainDepartureList = new ArrayList<>();
		
		String[] directions = {"SB", "NB"};
		
		nDays = 30;
		
		for (int i = 0; i < nDays; i++) {
			
			calendar.setTime(startDate);
			
			calendar.add(Calendar.DAY_OF_YEAR, i);
			
			Date currentDate = calendar.getTime();
			
			for (String direction: directions) {
				
				List<String> curTrainIdList = generateTrainIdHelper(direction);
				
				List<String> curTrainDepartureList = generateTrainDepartureList(currentDate);
				
				trainIdList.addAll(curTrainIdList);
				
				trainDepartureList.addAll(curTrainDepartureList);
				
//				for (int j = 0; j < curTrainIdList.size(); j++) {
//
//					if (i == 0) System.out.println(curTrainIdList.get(j) + "=======" + trainDepartureList.get(j));
//				}
				
			
				
			}
			
		}
		
		result.add(trainIdList);
		result.add(trainDepartureList);
		
		return result;
	}
	
	public static Query getResetTrainAvailabilityQuery(Date startDate, int quantity, int nDays) {
		
		System.out.println("Quantity==============" + quantity);
		System.out.println("nDays==============" + nDays);
		
		List<List<String>> list = getResetTrainAvailabilityQueryHelper(startDate, quantity, nDays);
		
		String deleteSql = "DELETE FROM TRAIN_AVAILABILITY; ";
		
		String insertSql = "INSERT INTO TRAIN_AVAILABILITY VALUES ";
		
		List<String> trainIdList = list.get(0);
		
		List<String> trainDepartureList = list.get(1);
		
		String value = null;
		
		char column;
		
		for (int i = 0; i < trainIdList.size(); i++) {
			
			value = "(" + trainIdList.get(i) + ", " + trainDepartureList.get(i) + ", ";
			
			for (int j = 0; j < 26; j++) {
				
				column = (char)('A' + j);
				
				value += String.valueOf(column);
				
				value += (j == 25) ? "=?" : "=?, ";
				
			}
			
			value += " )";
			
		}
		
		insertSql += value + ";";
		
		String sql = deleteSql + insertSql;
		
		System.out.println("sql ======" + sql);
		
		Query query = entityManager.createNativeQuery(sql);
		
		for (int i = 0; i < nDays; i++) {
			for (int j = 0; j < 26; j++) {
				query.setParameter(i * 26 + j + 1, quantity);
			}
		}
		
		return query;
	}
	
	public static float calculatePrice(String origination, String destination, String trainId, String trainType) {
		double price = 0;
		int nStops = trainId.toUpperCase().contains("SB") ?
			destination.charAt(0) - origination.charAt(0) :
			origination.charAt(0) - destination.charAt(0);
		System.out.println("nStops======" + nStops);
		if (trainType.toUpperCase().equals("REGULAR")) {
			price = (nStops / 5) * REGULAR_FARE;
			
			price += nStops % 5 == 0 ? 0 : REGULAR_FARE;
			
			System.out.println("regular price======" + price);
			
		} else { // Express Train
			price = Math.ceil((double)(nStops / 5)) * EXPRESS_FARE;
			
			System.out.println("express price======" + price);
		}
		
		return (float)price;
	}
	
	public static String getBookingConfirmationEmailContent(Booking booking) {
		
		String emailContent = "Congratulations, your tickets have been successfully booked!\n\n";
		
		Passenger passenger = booking.getPassenger();
		
		emailContent += "Passenger Name: " + passenger.getFirstname().toUpperCase() + " " + passenger.getLastname().toUpperCase() + "\n";
		
		emailContent += "Number Of Passengers: " + booking.getNumberOfPassengers() + "\n";
		
		emailContent += "Trip Type: " + (booking.isRoundTrip() ? "Round Trip" : "One Way") + "\n";
		
		emailContent += "Total Price: $" + booking.getBookingTotalPrice() + "\n\n\n";
		
		emailContent += "\n";
		
		emailContent += "Itinerary: \n\n";
		for (Ticket ticket: booking.getTicketList()) {
			
			
			
			emailContent += "Ticket ID: " + ticket.getId() + "\n";
			
			emailContent += "Origination: " + ticket.getOrigination() + "\n";
			
			emailContent += "Destination: " + ticket.getDestination() + "\n";
			
			emailContent += "Departure Time: " + ticket.getDepartureTime() + "\n";
			
			emailContent += "Arrival Time: " + ticket.getArrivalTime() + "\n";
		}
		
		emailContent += "\n";
		
		System.out.println("Email content======\n" + emailContent);
		return emailContent;
	}
	
	public static String getCancellationConfirmationEmailContent(Booking booking) {
		
		String emailContent = "Your tickets have been successfully cancelled!\n\n";
		
		Passenger passenger = booking.getPassenger();
		
		emailContent += "Passenger Name: " + passenger.getFirstname().toUpperCase() + " " + passenger.getLastname().toUpperCase() + "\n";
		
		emailContent += "Number Of Passengers: " + booking.getNumberOfPassengers() + "\n";
		
		emailContent += "Trip Type: " + (booking.isRoundTrip() ? "Round Trip" : "One Way") + "\n";
		
		emailContent += "Total Price: $" + booking.getBookingTotalPrice() + "\n\n\n";
		
		emailContent += "\n";
		
		emailContent += "Itinerary: \n\n";
		for (Ticket ticket: booking.getTicketList()) {
			
			
			
			emailContent += "Ticket ID: " + ticket.getId() + "\n";
			
			emailContent += "Origination: " + ticket.getOrigination() + "\n";
			
			emailContent += "Destination: " + ticket.getDestination() + "\n";
			
			emailContent += "Departure Time: " + ticket.getDepartureTime() + "\n";
			
			emailContent += "Arrival Time: " + ticket.getArrivalTime() + "\n";
		}
		
		emailContent += "\n";
		
		System.out.println("Email content======\n" + emailContent);
		return emailContent;
	}
}
