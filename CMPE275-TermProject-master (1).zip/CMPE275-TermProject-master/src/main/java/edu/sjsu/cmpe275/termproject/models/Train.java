package edu.sjsu.cmpe275.termproject.models;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.*;
import java.util.List;

@Entity
public class Train {
	@Id
	private String id;
	private String type;
	
	@OneToMany(mappedBy = "train")
	@JsonManagedReference
	List<TrainAvailability> trainAvailabilityList;
	
	private int A;
	private int B;
	private int C;
	private int D;
	private int E;
	private int F;
	private int G;
	private int H;
	private int I;
	private int J;
	private int K;
	private int L;
	private int M;
	private int N;
	private int O;
	private int P;
	private int Q;
	private int R;
	private int S;
	private int T;
	private int U;
	private int V;
	private int W;
	private int X;
	private int Y;
	private int Z;
	
	
	public String getId() {
		return id;
	}
	
	public String getType() {
		return type;
	}
	
	public List<TrainAvailability> getTrainAvailabilityList() {
		return trainAvailabilityList;
	}
	
	@JsonIgnore
	public int getA() {
		return A;
	}
	@JsonIgnore
	public int getB() {
		return B;
	}
	@JsonIgnore
	public int getC() {
		return C;
	}
	@JsonIgnore
	public int getD() {
		return D;
	}
	@JsonIgnore
	public int getE() {
		return E;
	}
	@JsonIgnore
	public int getF() {
		return F;
	}
	@JsonIgnore
	public int getG() {
		return G;
	}
	@JsonIgnore
	public int getH() {
		return H;
	}
	@JsonIgnore
	public int getI() {
		return I;
	}
	@JsonIgnore
	public int getJ() {
		return J;
	}
	@JsonIgnore
	public int getK() {
		return K;
	}
	@JsonIgnore
	public int getL() {
		return L;
	}
	@JsonIgnore
	public int getM() {
		return M;
	}
	@JsonIgnore
	public int getN() {
		return N;
	}
	@JsonIgnore
	public int getO() {
		return O;
	}
	@JsonIgnore
	public int getP() {
		return P;
	}
	@JsonIgnore
	public int getQ() {
		return Q;
	}
	@JsonIgnore
	public int getR() {
		return R;
	}
	@JsonIgnore
	public int getS() {
		return S;
	}
	@JsonIgnore
	public int getT() {
		return T;
	}
	@JsonIgnore
	public int getU() {
		return U;
	}
	@JsonIgnore
	public int getV() {
		return V;
	}
	@JsonIgnore
	public int getW() {
		return W;
	}
	@JsonIgnore
	public int getX() {
		return X;
	}
	@JsonIgnore
	public int getY() {
		return Y;
	}
	@JsonIgnore
	public int getZ() {
		return Z;
	}
}