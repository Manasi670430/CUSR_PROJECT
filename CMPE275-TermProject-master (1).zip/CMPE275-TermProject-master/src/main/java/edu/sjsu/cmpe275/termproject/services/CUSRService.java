package edu.sjsu.cmpe275.termproject.services;

import edu.sjsu.cmpe275.termproject.models.Passenger;
import edu.sjsu.cmpe275.termproject.models.Train;
import org.json.simple.JSONObject;

import java.text.ParseException;

public interface CUSRService {
	
	public JSONObject fetchTrain(String departureTime,String returnTime, String origin, String destination, String trainType, int noOfPassengers, int noOfConnections, boolean isRoundTrip, boolean isExactTime);

	public Passenger fetchUser(String userId);

	public Train bookTrain(String trainNo);

	public Passenger registerPassenger(String userId, String name, String email);

	public JSONObject cancelTrain(String trainId, String trainDate) throws ParseException;

	public Passenger updatePassenger(Passenger passenger);

	public JSONObject cancelTicket(int id);
	
}
