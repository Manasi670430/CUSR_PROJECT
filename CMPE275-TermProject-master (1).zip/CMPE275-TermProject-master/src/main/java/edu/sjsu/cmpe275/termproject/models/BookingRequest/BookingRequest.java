package edu.sjsu.cmpe275.termproject.models.BookingRequest;

import java.util.ArrayList;
import java.util.List;

/**
 * BookingRequest is used by BookingService to create a booking for passengers
 */
public class BookingRequest {
	
	private String passengerId;
	private String passengerEmail;
	private boolean isRoundTrip;
	private List<TicketRequest> ticketRequestList;
	private int numberOfPassengers;
	
	public BookingRequest(String passengerId, boolean isRoundTrip, int numberOfPassengers) {
		this.passengerId = passengerId;
		this.isRoundTrip = isRoundTrip;
		this.numberOfPassengers = numberOfPassengers;
		ticketRequestList = new ArrayList<TicketRequest>();
	}
	
	/** Getters **/
	public String getPassengerId() {
		return passengerId;
	}
	
	public String getPassengerEmail() {
		return passengerEmail;
	}
	
	public boolean isRoundTrip() {
		return isRoundTrip;
	}
	
	public List<TicketRequest> getTicketRequestList() {
		return ticketRequestList;
	}
	
	public int getNumberOfPassengers() {
		return numberOfPassengers;
	}
	
	/** Setters **/
	public void setPassengerId(String passengerId) {
		this.passengerId = passengerId;
	}
	
	public void setPassengerEmail(String passengerEmail) {
		this.passengerEmail = passengerEmail;
	}
	
	public void setTicketRequestList(List<TicketRequest> ticketRequestList) {
		this.ticketRequestList = ticketRequestList;
	}
	
	public void setRoundTrip(boolean roundTrip) {
		isRoundTrip = roundTrip;
	}
	
	public void setNumberOfPassengers(int numberOfPassengers) {
		this.numberOfPassengers = numberOfPassengers;
	}
	
	/** Additional methods **/
	public void addTicketRequest(TicketRequest ticketRequest) {
		ticketRequestList.add(ticketRequest);
	}
}
