/**
 * 
 */
package edu.sjsu.cmpe275.termproject.controller;

import edu.sjsu.cmpe275.termproject.dao.BookingRepository;
import edu.sjsu.cmpe275.termproject.models.Booking;
import edu.sjsu.cmpe275.termproject.models.Passenger;
import edu.sjsu.cmpe275.termproject.services.CUSRServiceImpl;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import edu.sjsu.cmpe275.termproject.models.SearchRequest;
import edu.sjsu.cmpe275.termproject.services.CUSRService;
import javax.servlet.http.HttpServletRequest;

/**
 * @author Abhishek
 *
 */
@RestController("/")
public class CUSRMainController {
	
	@Autowired
	private CUSRService cusrService;
	
	@Autowired
	private BookingRepository bookingRepository;

// This path will be serve the login page of CUSR website
//	@RequestMapping(value="/", method=RequestMethod.GET)
//	public String sayHello()
//	{
//		return "Hello World";
//	}
	
	@RequestMapping(value="/register", method=RequestMethod.POST)
	public ResponseEntity<?> registerUser(HttpServletRequest request )//@RequestParam String userId, @RequestParam String name,@RequestParam String email)
	{
	    Passenger passenger = cusrService.registerPassenger(request.getParameter("userId"), request.getParameter("name"), request.getParameter("email"));

        return new ResponseEntity<>(passenger, HttpStatus.OK);
	}


    @RequestMapping(value="/cancelTicket", method=RequestMethod.POST)
    public ResponseEntity<?> cancelTicket(HttpServletRequest request)
    {
        JSONObject obj = cusrService.cancelTicket(Integer.parseInt(request.getParameter("id")));
        
//        Booking booking = bookingRepository.findOne(Integer.valueOf(request.getParameter("id")));
        
        
        return new ResponseEntity<>(obj, HttpStatus.OK);
    }

	@RequestMapping(value="/user", method=RequestMethod.GET)
	public ResponseEntity<?> getUser(@RequestParam String userId)
	{
	    Passenger passenger = cusrService.fetchUser(userId);

	    if(passenger!=null)
		    return new ResponseEntity<>(passenger, HttpStatus.OK);
	    else
        {
            JSONObject errObj = new JSONObject();
            errObj.put("msg","No User Exists");
            return new ResponseEntity<>(errObj, HttpStatus.OK);
        }
	}

    @RequestMapping(value="/user", method=RequestMethod.POST)
    public ResponseEntity<?> saveUpdateUser(@RequestParam String userId, @RequestParam String name, @RequestParam String email)
    {
        Passenger passenger = null;
        Passenger updatedPassenger = null;
        if(userId!=null)
        {
            passenger = cusrService.fetchUser(userId);
        }

        if(passenger!=null)
        {
            if(name!=null)
            {
                passenger.setFirstname(name.split(" ")[0]);
                passenger.setLastname(name.split(" ")[1]);
            }
            if(email!=null)
                passenger.setEmail(email);

            updatedPassenger = cusrService.updatePassenger(passenger);
        }
        if(updatedPassenger!=null)
            return new ResponseEntity<>(updatedPassenger, HttpStatus.OK);
        else
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

	@RequestMapping(value="/searching", method=RequestMethod.POST,  consumes="application/json")
	public JSONObject getTrain(@RequestBody SearchRequest request)
	{
		String departureTime = request.getDepartureTime();
		String origin = request.getOrigin();
		String destination = request.getDestination();
		String trainType = request.getTrainType();
		int noOfPassengers = request.getNumberOfPassengers();
		int noOfConnections = request.getNumberOfConnections();
		boolean isRoundTrip = request.isRoundTrip();
		boolean isExactTime = request.isExactTime();
        String returnTime = request.getReturnTime();

		JSONObject results = cusrService.fetchTrain(departureTime,returnTime,origin,destination,trainType,noOfPassengers,noOfConnections,isRoundTrip,isExactTime);
		return results;
	}

    /*@RequestMapping(value="/cancelTrain", method=RequestMethod.POST)
    public ResponseEntity<?> cancelTrain(HttpServletRequest request)
    {
        JSONObject obj = cusrService.cancelTrain(request.getParameter("trainId"), request.getParameter("trainDate"));
        return new ResponseEntity<>(obj, HttpStatus.OK);
    }*/



}
