package edu.sjsu.cmpe275.termproject.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.Properties;

@Service
public class EmailServiceImpl implements EmailService{
	@Autowired
	@Qualifier("myEmailSender")
	private JavaMailSender emailSender;
	
	@Override
	@Async
	public void sendEmail(String recipient, String subject, Object content) {
		
		String text = content.toString();
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(recipient);
		message.setSubject(subject);
		message.setText(text);
		emailSender.send(message);
	}
}
