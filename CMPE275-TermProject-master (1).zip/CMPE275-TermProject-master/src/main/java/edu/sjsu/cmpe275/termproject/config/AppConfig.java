package edu.sjsu.cmpe275.termproject.config;

import edu.sjsu.cmpe275.termproject.services.BookingService;
import edu.sjsu.cmpe275.termproject.services.BookingServiceImpl;
import edu.sjsu.cmpe275.termproject.services.EmailService;
import edu.sjsu.cmpe275.termproject.services.EmailServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import java.util.Properties;

@Configuration
public class AppConfig {
	@Bean
	public BookingServiceImpl bookingServiceImpl() {
		return new BookingServiceImpl();
	}
	
	@Bean
	public EmailService emailService() {
		return new EmailServiceImpl();
	}
	
	@Bean(name = "myEmailSender")
	public JavaMailSender javaMailSender() {
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		Properties mailProperties = new Properties();
		mailProperties.put("mail.smtp.auth", true);
		mailProperties.put("mail.smtp.starttls.enable", true);
		mailSender.setJavaMailProperties(mailProperties);
		mailSender.setHost("smtp.gmail.com");
		mailSender.setPort(587);
		mailSender.setUsername("cmpe275.team.project@gmail.com");
		mailSender.setPassword("quickfox");
		return mailSender;
	}
}


