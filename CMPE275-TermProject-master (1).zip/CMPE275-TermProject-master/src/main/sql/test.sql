-- Join table to get ticket information -

USE CMPE275;

select

  B.id as bookingId, B.status,  B.isRoundTrip, B.createdAt,

  T.id as ticketId, T.trainId, T.date as departure, T.price, T.origination, T.destination, T.numberOfPassegers,

  P.id as passengerId, P.email, P.firstname, P.lastname, P.password

from Booking as B, Ticket as T, Passenger as P

where B.id = T.bookingId AND P.id = B.passengerId;