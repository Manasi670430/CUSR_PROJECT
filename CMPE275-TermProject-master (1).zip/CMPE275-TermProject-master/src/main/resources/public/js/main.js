$(document).ready(function () {

    $('#departureDate').attr({
        "min": moment().format('YYYY-MM-DD'),
        "max": moment().add(30, 'days').format('YYYY-MM-DD'),
        "value": moment().format('YYYY-MM-DD')
    });

    $('#departureTime').attr({
        "value": moment().format('kk:mm')
    });

    $('#returnDate').attr({
        "min": moment().format('YYYY-MM-DD'),
        "max": moment().add(7, 'days').format('YYYY-MM-DD'),
        "value": moment().format('YYYY-MM-DD')
    });

    $('#returnTime').attr({
        "value": moment().format('kk:mm')
    });

    $('input[name="trip"]').on('change', function () {
        var tripType = $("input[name='trip']:checked").val();
        console.log(tripType);
        if (tripType === "round") {
            $('.return-time-section').removeClass('hidden');
        } else {
            $('.return-time-section').addClass('hidden');
        }
    });

    // $('#trainType').on('change', function () {
    //     var trainType = $('#trainType').val();
    //     console.log(trainType);
    //     if (trainType === "express") {
    //         $('#origin option').remove();
    //         $('#destination option').remove();
    //         var station;
    //         for (i = 65; i <= 85; i += 5) {
    //             station = String.fromCharCode(i);
    //             $('<option>').val(station).text(station).appendTo('#origin');
    //         }
    //         for (i = 70; i <= 90; i += 5) {
    //             station = String.fromCharCode(i);
    //             $('<option>').val(station).text(station).appendTo('#destination');
    //         }

    //     } else {
    //         $('#origin option').remove();
    //         $('#destination option').remove();
    //         var station
    //         for (i = 65; i <= 89; i++) {
    //             station = String.fromCharCode(i);
    //             $('<option>').val(station).text(station).appendTo('#origin');
    //         }
    //         for (i = 66; i <= 90; i++) {
    //             station = String.fromCharCode(i);
    //             $('<option>').val(station).text(station).appendTo('#destination');
    //         }
    //     }
    // })

    // $('#origin').on('change', function () {
    //     var trainType = $('#trainType').val();
    //     var origin = $('#origin').val();
    //     var originStationNumber = origin.charCodeAt(0);
    //     var station;
    //     $('#destination option').remove();
    //     if (trainType === "express") {
    //         for (i = originStationNumber + 5; i <= 90; i += 5) {
    //             station = String.fromCharCode(i);
    //             $('<option>').val(station).text(station).appendTo('#destination');
    //         }
    //     } else {
    //         for (i = originStationNumber + 1; i <= 90; i++) {
    //             station = String.fromCharCode(i);
    //             $('<option>').val(station).text(station).appendTo('#destination');
    //         }
    //     }
    // });

    $('#departureDate').on('change', function () {
        $('#returnDate').attr({
            "min": $('#departureDate').val(),
            "max": moment(($('#departureDate').val()), 'YYYY-MM-DD').add(7, 'days').format('YYYY-MM-DD'),
            "value": $('#departureDate').val()
        });
    });

    $('#search-results-section').on('click', '.btn', function () {

        var data = JSON.parse(($(this).closest('[data-result]')).attr("data-result"));
        console.log(data);

        // create booking request
        var bookingRequest = {};
        bookingRequest['numberOfPassengers'] = data.from.numberOfPassengers;
        bookingRequest['passengerId'] = userId; // TODO fetch and put

        if (jQuery.isEmptyObject(data.return)  || data.return === ""){
            var roundtrip = false;
        }else {
            var roundtrip = true;
        }
        //var roundtrip = !jQuery.isEmptyObject(data.return)  ? 'false' : 'true';
        bookingRequest['roundTrip'] = roundtrip;
        bookingRequest['ticketRequestList'] = [];
        bookingRequest['totalcost'] = data.from.totalPrice;
        bookingRequest['ticketRequestList'][0] = { "sectionRequestList": [] }; // oneway;

        // create oneway trip data
        if (data.from.numberOfStops === 0) {
            var sectionInfo = {};
            sectionInfo['origination'] = data.from.origin;
            sectionInfo['destination'] = data.from.destination
            sectionInfo['trainId'] = data.from.trainId;
            sectionInfo['cost'] = data.from.totalPrice;
            sectionInfo['date'] = data.from.departure;//moment(data.from.departure, 'YYYY-MM-DD kk:mm:ss').format('YYYY-MM-DD');

            bookingRequest['ticketRequestList'][0]['sectionRequestList'].push(sectionInfo);
        } else {
            data.from.sections.forEach(function (section) {
                var sectionInfo = {};
                sectionInfo['origination'] = section.origin;
                sectionInfo['destination'] = section.destination;
                sectionInfo['trainId'] = section.trainId;
                sectionInfo['cost'] = section.totalPrice;
                sectionInfo['date'] = section.departure;//moment(section.departure, 'YYYY-MM-DD kk:mm:ss').format('YYYY-MM-DD');

                bookingRequest['ticketRequestList'][0]['sectionRequestList'].push(sectionInfo);
            });
        }

        if (roundtrip === true) {

            bookingRequest['ticketRequestList'][1] = { "sectionRequestList": [] }; // roundtrip;
            // create round trip data
            if (data.return.numberOfStops === 0) {
                var sectionInfo = {};
                sectionInfo['origination'] = data.return.origin;
                sectionInfo['destination'] = data.return.destination
                sectionInfo['trainId'] = data.return.trainId;
                sectionInfo['cost'] = data.return.totalPrice;
                sectionInfo['date'] = data.return.departure;//moment(data.return.departure, 'YYYY-MM-DD kk:mm:ss').format('YYYY-MM-DD');

                bookingRequest['ticketRequestList'][0]['sectionRequestList'].push(sectionInfo);
            } else {
                data.return.sections.forEach(function (section) {
                    console.log("section==========" + section);
                    var sectionInfo = {};
                    sectionInfo['origination'] = section.origin;
                    sectionInfo['destination'] = section.destination;
                    sectionInfo['trainId'] = section.trainId;
                    sectionInfo['cost'] = section.totalPrice;
                    sectionInfo['date'] = section.departure;//moment(section.departure, 'YYYY-MM-DD kk:mm:ss').format('YYYY-MM-DD');

                    bookingRequest['ticketRequestList'][0]['sectionRequestList'].push(sectionInfo);
                });
            }
        }

        console.log("BOOKING REQUEST");
        console.log(bookingRequest);
        console.log(JSON.stringify(bookingRequest));

        $.ajax('/user/booking', {
            type: 'POST',
            data: JSON.stringify(bookingRequest),
            contentType: 'application/json',
            success: function (bookingResult) {
                console.log(bookingResult);
                $('.modal-body .booking-content').remove();
                var bookingContent = 'Booking Number '+ bookingResult.id;
                // '<div class="booking-content">' +
                //     '<p>Ticket Number - '+bookingResult.id +'</p>'+
                //     '<p>Number of Passengers - '+bookingResult.numberOfPassengers +'</p>'+
                //     '<p>Number of Passengers - '+bookingResult.numberOfPassengers +'</p>'+
                // '</div>'
                $('.modal-body ').append(bookingContent);
                $('#bookingModal').modal({ show: true });
            },
            error: function (req, status, err) {
                console.log('something went wrong', status, err);
            }
        });

    })


    $('.search-train').on('click', function () {
        $('div[data-result]').remove();
        $('.no-data').remove();
        $('#validation-error span').text("");
        var validationPassed = true;
        var roundTrip = $("input[name='trip']:checked").val() === "round" ? true : false;
        var departureTime = $('#departureDate').val() + " " + $('#departureTime').val() + ":00";
        var returnTime = $('#returnDate').val() + " " + $('#returnTime').val() + ":00";
        var exactTime = $('#exactTime').prop('checked') ? true : false;
        var departureTimeExact = parseInt(moment(($('#departureTime').val()), "kk:mm").format("kkmm"));
        var returnTimeExact = parseInt(moment(($('#returnTime').val()), "kk:mm").format("kkmm"));
        var origin = $('#origin').val();
        var destination = $('#destination').val();

        if (origin === destination){
            validationPassed = false;
            console.log("Origin same as destination");
            $('#validation-error span').append("Origin cannot be same as destination");
        }
        else if (moment(departureTime) < moment()) {
            validationPassed = false;
            console.log("Departure Time is less");
            $('#validation-error span').append("Departure Time should be greater than current time");
        } else if (exactTime && (departureTimeExact < 600 || departureTimeExact > 2100)) {
            validationPassed = false;
            $('#validation-error span').append("Invalid Time. Time should be between 6AM and 9PM");
        } else if (roundTrip === true && departureTime >= returnTime) {
            validationPassed = false;
            $('#validation-error span').append("Departure Time should be greater than Return Time.");
        } else if (roundTrip && exactTime && (returnTimeExact < 600 || returnTimeExact > 2100)) {
            validationPassed = false;
            $('#validation-error span').append("Invalid Time. Time should be between 6AM and 9PM");
        }

        console.log(departureTime);
        console.log(moment().toDate());
        console.log(moment(returnTime).toDate());
        console.log(moment(departureTime).toDate() < moment(returnTime).toDate());

        if (validationPassed) { // on validation successful

            $('#validation-error-section').addClass('hidden');

            var requestData = {}
            requestData["roundTrip"] = roundTrip;
            requestData["origin"] = $('#origin').val();
            requestData["destination"] = $('#destination').val();
            requestData["exactTime"] = exactTime;

            requestData["departureTime"] = departureTime,  //"2017-12-01 10:00:00",
            requestData["roundTrip"] ? requestData["returnTime"] = returnTime : "";
            requestData["trainType"] = $('#trainType').val();
            requestData["numberOfConnections"] = $('#connections').val();
            requestData["numberOfPassengers"] = $('#passenger').val();

            console.log(requestData);
            console.log(JSON.stringify(requestData));

            $.ajax('/searching', { // TODO Replace with /searching
                type: 'POST',
                data: JSON.stringify(requestData),
                contentType: 'application/json',
                success: function (searchResult) {
                    console.log(searchResult);
                    // searchResult = {
                    //     "itineraries": [
                    //         {
                    //             "from": {
                    //                 "trainId": "SB600",
                    //                 "numberOfStops": 1,
                    //                 "arrival": "2017-12-20 10:00:00",
                    //                 "totalPrice": 2,
                    //                 "origin": "A",
                    //                 "destination": "F",
                    //                 "numberOfPassengers": 1,
                    //                 "departure": "2017-12-20 06:00:00",
                    //                 "type": "Express",
                    //                 "sections": [
                    //                     {
                    //                         "trainId": "SB600",
                    //                         "numberOfStops": 0,
                    //                         "arrival": "2017-12-20 06:08:00",
                    //                         "totalPrice": 2,
                    //                         "origin": "A",
                    //                         "destination": "B",
                    //                         "numberOfPassengers": 1,
                    //                         "departure": "2017-12-20 06:00:00",
                    //                         "type": "Express"
                    //                     },
                    //                     {
                    //                         "trainId": "SB615",
                    //                         "numberOfStops": "0",
                    //                         "arrival": "2017-12-20 06:52:00",
                    //                         "totalPrice": 1,
                    //                         "origin": "B",
                    //                         "destination": "F",
                    //                         "numberOfPassengers": "1",
                    //                         "departure": "2017-12-20 06:15:00",
                    //                         "type": "Regular"
                    //                     }
                    //                 ]
                    //             },
                    //             "return": {
                    //                 "trainId": "SB600",
                    //                 "numberOfStops": 1,
                    //                 "arrival": "2017-12-20 10:00:00",
                    //                 "totalPrice": 2,
                    //                 "origin": "F",
                    //                 "destination": "A",
                    //                 "numberOfPassengers": 1,
                    //                 "departure": "2017-12-20 06:00:00",
                    //                 "type": "Express",
                    //                 "sections": [
                    //                     {
                    //                         "trainId": "SB600",
                    //                         "numberOfStops": 0,
                    //                         "arrival": "2017-12-20 06:08:00",
                    //                         "totalPrice": 2,
                    //                         "origin": "F",
                    //                         "destination": "B",
                    //                         "numberOfPassengers": 1,
                    //                         "departure": "2017-12-20 06:00:00",
                    //                         "type": "Express"
                    //                     },
                    //                     {
                    //                         "trainId": "SB615",
                    //                         "numberOfStops": "0",
                    //                         "arrival": "2017-12-20 06:52:00",
                    //                         "totalPrice": 1,
                    //                         "origin": "B",
                    //                         "destination": "A",
                    //                         "numberOfPassengers": "1",
                    //                         "departure": "2017-12-20 06:15:00",
                    //                         "type": "Regular"
                    //                     }
                    //                 ]
                    //             },
                    //         },
                    //         {
                    //             "from": {
                    //                 "numberOfStops": 0,
                    //                 "arrival": "2017-12-20 06:52:00",
                    //                 "totalPrice": 1,
                    //                 "origin": "A",
                    //                 "destination": "F",
                    //                 "numberOfPassengers": 1,
                    //                 "departure": "2017-12-20 06:15:00",
                    //                 "type": "Regular",
                    //                 "sections": []
                    //             },
                    //             "return": {}
                    //         },
                    //         {
                    //             "from": {
                    //                 "numberOfStops": 1,
                    //                 "arrival": "2017-12-20 07:07:00",
                    //                 "totalPrice": 1,
                    //                 "origin": "A",
                    //                 "destination": "F",
                    //                 "numberOfPassengers": 1,
                    //                 "departure": "2017-12-20 06:30:00",
                    //                 "type": "Regular",
                    //                 "sections": []
                    //             },
                    //             "return": {}
                    //         },
                    //         {
                    //             "from": {
                    //                 "numberOfStops": 1,
                    //                 "arrival": "2017-12-20 07:22:00",
                    //                 "totalPrice": 1,
                    //                 "origin": "A",
                    //                 "destination": "F",
                    //                 "numberOfPassengers": 1,
                    //                 "departure": "2017-12-20 06:45:00",
                    //                 "type": "Regular",
                    //                 "sections": []
                    //             },
                    //             "return": {}
                    //         },
                    //         {
                    //             "from": {
                    //                 "numberOfStops": 1,
                    //                 "arrival": "2017-12-20 07:36:00",
                    //                 "totalPrice": 2,
                    //                 "origin": "A",
                    //                 "destination": "F",
                    //                 "numberOfPassengers": 1,
                    //                 "departure": "2017-12-20 07:00:00",
                    //                 "type": "Express",
                    //                 "sections": []
                    //             },
                    //             "return": {}
                    //         }
                    //     ],
                    //     "roundTrip": false
                    // };
                    var itineraries = searchResult.itineraries;

                    itineraries.forEach(function (itinerary, idx) {
                        var trip = itinerary.from;
                        var returnTrip = searchResult.roundTrip ? itinerary.return : "";

                        var stops = trip.numberOfStops === 0 ? "None" : trip.numberOfStops;
                        var fromDepart = moment(trip.departure, 'YYYY-MM-DD kk:mm:ss').format('MMM D, YYYY kk:mm');
                        var fromArrival = moment(trip.arrival, 'YYYY-MM-DD kk:mm:ss').format('MMM D, YYYY kk:mm');
                        //var fromDepart = moment(trip.departure,'YYYY-MM-DD kk:mm:ss').format('MMM D, YYYY hh:mm a');
                        console.log(trip);
                        // Add one way
                        var itineraryBlock =
                            "<div class='row' id='result" + idx + "' data-result='" + JSON.stringify(itinerary) + "'>" +
                                '<div class="col-10 trip-details">' +
                                    '<div class="row trip">' +
                                        '<div class="col-3">' + trip.origin + " - " + trip.destination + '</div>' +
                                        '<div class="col-3">' + fromDepart +'<br>'+ fromArrival + '</div>' +
                                        '<div class="col-2">' + trip.type + '</div>' +
                                        '<div class="col-1">' + stops + '</div>' +
                                        '<div class="col-2">' + trip.numberOfPassengers + '</div>' +
                                        '<div class="col-1">$' + trip.totalPrice + '</div>' +
                                    '</div>';
                        var sections = trip.sections;
                        // ADD one way Sections
                        sections.forEach(function(section){
                            var sectionDepart = moment(section.departure, 'YYYY-MM-DD kk:mm:ss').format('MMM D, YYYY kk:mm');
                            var sectionArrival = moment(section.arrival, 'YYYY-MM-DD kk:mm:ss').format('MMM D, YYYY kk:mm');

                            itineraryBlock = itineraryBlock + 
                                    '<div class="row section">' +
                                        '<div class="col-3">' + section.origin + " - " + section.destination + '</div>' +
                                        '<div class="col-3">' + sectionDepart +'<br>'+ sectionArrival + '</div>' +
                                        '<div class="col-2">' + section.type + '</div>' +
                                        '<div class="col-1">' + section.numberOfStops + '</div>' +
                                        '<div class="col-2">' + section.numberOfPassengers + '</div>' +
                                        '<div class="col-1">$' + section.totalPrice + '</div>' +
                                    '</div>';
                        });


                        // Add Round Trip
                        //if (true){
                        if (searchResult.roundTrip) {

                            var returnStops = returnTrip.numberOfStops === 0 ? "NonStop" : returnTrip.numberOfStops;
                            var returnDepart = moment(returnTrip.departure, 'YYYY-MM-DD kk:mm:ss').format('MMM D, YYYY kk:mm');
                            var returnArrival = moment(returnTrip.arrival, 'YYYY-MM-DD kk:mm:ss').format('MMM D, YYYY kk:mm');

                            itineraryBlock = itineraryBlock +
                                '<div class="row returntrip">' +
                                '<div class="col-3">' + returnTrip.origin + " - " + returnTrip.destination + '</div>' +
                                '<div class="col-3">' + returnDepart +'<br>'+ returnArrival + '</div>' +
                                '<div class="col-2">' + returnTrip.type + '</div>' +
                                '<div class="col-1">' + returnStops + '</div>' +
                                '<div class="col-2">' + returnTrip.numberOfPassengers + '</div>' +
                                '<div class="col-1">$' + returnTrip.totalPrice + '</div>' +
                                '</div>';

                            // ADD return trip Sections

                            var returnSections = returnTrip.sections;
                            // ADD one way Sections
                            returnSections.forEach(function(section){
                                var sectionDepart = moment(section.departure, 'YYYY-MM-DD kk:mm:ss').format('MMM D, YYYY kk:mm');
                                var sectionArrival = moment(section.arrival, 'YYYY-MM-DD kk:mm:ss').format('MMM D, YYYY kk:mm');
                                itineraryBlock = itineraryBlock + 
                                        '<div class="row section">' +
                                            '<div class="col-3">' + section.origin + " - " + section.destination + '</div>' +
                                            '<div class="col-3">' + sectionDepart +'<br>'+ sectionArrival + '</div>' +
                                            '<div class="col-2">' + section.type + '</div>' +
                                            '<div class="col-1">' + section.numberOfStops + '</div>' +
                                            '<div class="col-2">' + section.numberOfPassengers + '</div>' +
                                            '<div class="col-1">$' + section.totalPrice + '</div>' +
                                        '</div>';
                            });
                        }
                        // Add close button
                        itineraryBlock = itineraryBlock +
                            '</div>' +
                            '<div class="col-2 m-auto"><input type="button" class="btn btn-outline-primary btn-sm " id="btn-result' + idx + '" value="Book"></div>' +
                            '</div>';
                        $('#search-results-section').removeClass('hidden');
                        $('#search-results-section').append(itineraryBlock);
                    });

                    if (itineraries.length === 0){
                        $('.container').append('<div class="row no-data"> <div class="col-12 text-center"> No Results Found </div> </div>');
                    }

                },
                error: function (req, status, err) {
                    console.log('something went wrong', status, err);
                }
            });
        } else {
            $('#validation-error-section').removeClass('hidden');
        }
    });

});