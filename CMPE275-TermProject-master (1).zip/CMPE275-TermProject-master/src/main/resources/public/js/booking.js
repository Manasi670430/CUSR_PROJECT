
    function populateBookingTickets(data){
        data.forEach(function(ticket){
            console.log("TICKET");
            console.log(ticket);
            console.log(JSON.stringify(ticket));
            var oneway = ticket.ticketList[0];
            var onewayStops = oneway.sectionList.length -1;
            if (ticket.roundTrip){
                console.log()
                var returnTrip = ticket.ticketList[1];
            }

            var ticketBlock = 
            '<div class="row ticket text-center" data-bookingid = '+ticket.id+'>'+
            '<div class="col-10 ">'+
                '<div class="row">'+
                    '<div class="col-4">'+
                        '<b>Ticket Number</b>&nbsp;'+ticket.id+'</div>'+
                    '<div class="col-4">'+
                        '<b>Passengers</b>&nbsp;'+ticket.numberOfPassengers+'</div>'+
                    '<div class="col-4">'+
                        '<b>Total Cost</b>&nbsp; $'+ticket.bookingTotalPrice+'</div>'+
                '</div>'+
                '<div class="trip row">'+
                    '<div class="col-12">'+
                        '<div class="row">'+
                            '<div class="col-3">'+
                                '<b>Station &nbsp;</b> '+oneway.origination+"-"+oneway.destination+'</div>'+
                            '<div class="col-4">'+
                                '<b>Time</b> &nbsp;</b> '+
                                    moment(oneway.departureTime,'YYYY-MM-DD kk:mm:ss').format('MMM D, YYYY kk:mm') +
                                    "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + 
                                    moment(oneway.arrivalTime,'YYYY-MM-DD kk:mm:ss').format('MMM D, YYYY kk:mm') +
                            '</div>'+
                            '<div class="col-2">'+
                                '<b>Stops</b> &nbsp; ' +onewayStops+'</div>'+
                            '<div class="col-3">'+
                                '<b>Cost</b> &nbsp; $'+oneway.price+'</div>'+ 
                        '</div>'+
                        '<div class="row headings detail">'+
                            '<div class="col-4">Stations</div>'+
                            '<div class="col-4">Time</div>'+
                            '<div class="col-2">Train</div>'+
                            '<div class="col-2">Cost</div>'+
                        '</div>';
                        
                        oneway.sectionList.forEach(function(section){
                            ticketBlock = ticketBlock + 
                            '<div class="row detail">'+
                                '<div class="col-4">'+section.origination+'-'+section.destination+'</div>'+
                                '<div class="col-4">'+
                                    moment(section.departureTime,'YYYY-MM-DD kk:mm:ss').format('MMM D, YYYY kk:mm') +
                                    '<br>'+
                                    moment(section.arrivalTime,'YYYY-MM-DD kk:mm:ss').format('MMM D, YYYY kk:mm') +
                                '</div>'+
                                '<div class="col-2">'+section.trainAvailability.trainId+'</div>'+
                                '<div class="col-2">$'+section.price+'</div>'+ 
                        '</div>';
                        });
    
            ticketBlock = ticketBlock + 
                    '</div>'+
                '</div>';

                if (ticket.roundTrip){
                    var returnTripStops = returnTrip.sectionList.length -1;
                    ticketBlock = ticketBlock +
                '<div class="trip row">'+
                    '<div class="col-12">'+
                        '<div class="row">'+
                            '<div class="col-3">'+
                                '<b>Station &nbsp;</b> '+returnTrip.origination+"-"+returnTrip.destination+'</div>'+
                            '<div class="col-4">'+
                                '<b>Time</b> &nbsp;</b> '+
                                    moment(returnTrip.departureTime,'YYYY-MM-DD kk:mm:ss').format('MMM D, YYYY kk:mm') +
                                    "<br>" + 
                                    moment(returnTrip.arrivalTime,'YYYY-MM-DD kk:mm:ss').format('MMM D, YYYY kk:mm') +
                            '</div>'+
                            '<div class="col-2">'+
                                '<b>Stops</b> &nbsp; ' +returnTripStops+'</div>'+
                            '<div class="col-3">'+
                                '<b>Cost</b> &nbsp; $'+returnTrip.price+'</div>'+ 
                        '</div>'+
                        '<div class="row headings detail">'+
                            '<div class="col-4">Stations</div>'+
                            '<div class="col-4">Time</div>'+
                            '<div class="col-2">Train</div>'+
                            '<div class="col-2">Cost</div>'+
                        '</div>';
                        
                        returnTrip.sectionList.forEach(function(section){
                            ticketBlock = ticketBlock + 
                            '<div class="row detail">'+
                                '<div class="col-4">'+section.origination+'-'+section.destination+'</div>'+
                                '<div class="col-4">'+
                                    moment(section.departureTime,'YYYY-MM-DD kk:mm:ss').format('MMM D, YYYY kk:mm') +
                                    '<br>'+
                                    moment(section.arrivalTime,'YYYY-MM-DD kk:mm:ss').format('MMM D, YYYY kk:mm') +
                                '</div>'+
                                '<div class="col-2">'+section.trainAvailability.trainId+'</div>'+
                                '<div class="col-2">$'+section.price+'</div>'+ 
                        '</div>';
                        });
    
            ticketBlock = ticketBlock + 
                    '</div>'+
                '</div>';
                }

            ticketBlock = ticketBlock + 
            '</div>'+
            '<div class="col-2 m-auto">';
            
            if(ticket.status === 'Active' && moment(oneway.departureTime) < moment()){
                ticketBlock = ticketBlock + 
                '<input type="button" class="btn btn-outline-primary btn-sm ticket-cancel" value="Cancel">';
            }else {
                if (ticket.status === 'Inactive'){
                    ticketBlock = ticketBlock + '<span class="cancelled-text">Cancelled</span>'
                }else{
            ticketBlock = ticketBlock + 
                '<input type="button" class="btn btn-outline-primary btn-sm ticket-cancel disabled" value="Cancel">';
                }
            }

            ticketBlock = ticketBlock + 
            '</div>'+
        '</div>';

            $('#user-bookings-section').append(ticketBlock);
        });
    }

    $('#user-bookings-section').on('click','.ticket-cancel',function(){
        var bookingID= ($(this).closest('[data-bookingid]')).attr("data-bookingid");
        var cancelButton = $(this);
        var parent=$(this).parent();
        
        $.ajax('/cancelTicket?id='+bookingID, {
            type: 'POST',
            success: function (result) {
                console.log("Ticket Cancellation Result" + JSON.stringify(result));
                cancelButton.remove();
                parent.append('<span class="cancelled-text">Cancelled</span>');
            },
            error: function (req, status, err) {
                console.log('something went wrong', status, err.message);
            }
        });
    });