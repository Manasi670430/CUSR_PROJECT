$(document).ready(function() {
    // $.ajax({
    //     url: "http://rest-service.guides.spring.io/greeting"
    // }).then(function(data) {
    //    $('.greeting-id').append(data.id);
    //    $('.greeting-content').append(data.content);
    // });

    $('.btn-google').on('click',function(){
        googleLogin();
    });

    $('.btn-facebook').on('click',function(){
        facebookLogin();
    });

    $('.logout-link').on('click', function () {
        logout();
    });

});