$(document).ready(function () {

    for (i = 600; i <= 900; i += 15) {
        $('<option>').val('SB' + i).text('SB' + i).appendTo('#trainnumber');
        $('<option>').val('NB' + i).text('NB' + i).appendTo('#trainnumber');
    }

    $('#cancelTrainDate').attr({
        "min": moment().format('YYYY-MM-DD'),
        "max": moment().add(30, 'days').format('YYYY-MM-DD'),
        "value": moment().format('YYYY-MM-DD')
    });

    $('.reset-booking').on('click', function () {
        console.log("Inside reset button");
        $('#validation-error').text("");
        $('#status-message').text("");
        $('#status-message-section').addClass('hidden');
        $('#validation-error-section').addClass('hidden');
        var capacity = parseInt($('#capacity').val());
        console.log(capacity);
        if (capacity < 1 || capacity > 5000) {
            console.log("Inside validation logic");
            $('#validation-error').append("Train capacity should be between 1 and 5000");
            $('#validation-error-section').removeClass('hidden');
        } else {
            console.log("Inside validation passed");
            // CALL RESET API AND put below messages in success
            $('#status-message').append("Train bookings have been resetted and train capacity has been set to " + capacity);
            $('#status-message-section').removeClass('hidden');
        }
    });

    $('.cancel-train').on('click', function () {
        console.log("Inside reset button");
        $('#validation-error').text("");
        $('#status-message').text("");
        $('#status-message-section').addClass('hidden');
        $('#validation-error-section').addClass('hidden');
        var date = $('#cancelTrainDate').val();
        console.log(date);
        if (moment(date, 'YYYY-MM-DD').format('YYYYMMDD') < moment().format('YYYYMMDD')) {
            console.log("Inside validation logic");
            $('#validation-error').append("Invalid Train Cancellation Date. It should be greater than or equal to current date");
            $('#validation-error-section').removeClass('hidden');
        } else {
            console.log("Inside validation passed");
            // CALL CANCEL API AND put below messages in success
            $('#status-message').append("Train has been cancelled succesfully");
            $('#status-message-section').removeClass('hidden');
        }

    });
});