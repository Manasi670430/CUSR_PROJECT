$(document).ready(function () {

    $('.edit').on('click',function(){
        $("#name").prop("disabled", false);
        $("#email").prop("disabled", false);
        $('.edit').addClass('hidden');
        $('.save').removeClass('hidden');
    });

    $('.save').on('click',function(){
        console.log("userID:" +userId);
        $('#validation-error').text("");

        if ((($('#email')[0]).validity.valid) && (($('#name')[0]).validity.valid) ){
            $('#validation-error-section').addClass('hidden');
            console.log("valid email & name");
            var name = $('#name').val();
            var email = $('#email').val();
            if (newUser){
                console.log("Call register");
                
                $.ajax('/register?userId='+userId+'&name='+name+'&email='+email, {
                    type: 'POST',
                    success: function (result) {
                        console.log(result);
                        $("#name").prop("disabled", true);
                        $("#email").prop("disabled", true);
                        $('.edit').removeClass('hidden');
                        $('.save').addClass('hidden');
                    },
                    error: function (req, status, err) {
                        console.log('something went wrong', status, err);
                    }
                });
            }else {
                console.log("Call user info update");
                $.ajax('/user?userId='+userId+'&name='+name+'&email='+email, {
                    type: 'POST',
                    success: function (result) {
                        console.log(result);
                        $("#name").prop("disabled", true);
                        $("#email").prop("disabled", true);
                        $('.edit').removeClass('hidden');
                        $('.save').addClass('hidden');
                    },
                    error: function (req, status, err) {
                        console.log('something went wrong', status, err);
                    }
                });
            }

        }else {
            console.log("invalid email or name");
            $('#validation-error').append("Provide Name and valid Email Address");
            $('#validation-error-section').removeClass('hidden');
        }

    });
});