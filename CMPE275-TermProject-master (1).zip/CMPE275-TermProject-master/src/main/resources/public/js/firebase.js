var config = {
    apiKey: "AIzaSyApVJkHLWfwpfQFJqAfgdP42eLIoH5xEvc",
    authDomain: "cmpe275-cusr-dc65d.firebaseapp.com",
    databaseURL: "https://cmpe275-cusr-dc65d.firebaseio.com",
    projectId: "cmpe275-cusr-dc65d",
    storageBucket: "",
    messagingSenderId: "946621386371"
};

firebase.initializeApp(config);

function googleLogin() {
    
    var provider = new firebase.auth.GoogleAuthProvider();
    login(provider);
}

function facebookLogin() {
    var provider = new firebase.auth.FacebookAuthProvider();
    login(provider);
}

function login(provider) {
    firebase.auth().signInWithPopup(provider).then(function (result) {
        var token = result.credential.accessToken;
        // The signed-in user info.
        var user = result.user;
        console.log("User Signed In: " + JSON.stringify(result.user));
        window.location.replace('/main.html');

        firebase.auth().onAuthStateChanged(function(user) {
            if (user) {
              // User is signed in.
            } else {
              // No user is signed in.
              window.location.replace('/index.html');
            }
          });
          

    }).catch(function (error) {
        // Handle Errors here.
        var errorCode = error.code;
        var errorMessage = error.message;
        // The email of the user's account used.
        var email = error.email;
        // The firebase.auth.AuthCredential type that was used.
        var credential = error.credential;
        console.log(errorCode);
        console.log(errorMessage);
        if (errorCode === 'auth/account-exists-with-different-credential') {
            $('.login-dialog .row').prepend("<div class='col-12 text-center'>" +
                "<span class='badge badge-warning'>" +
                " <i class='fa fa-exclamation-triangle'></i>" +
                "  Account already exists. Try another provider." +
                "</span></div>")
        }
    });
}

function checkUserLoggedIn(cb) {
    firebase.auth().onAuthStateChanged(function (user) {
        if (user) {
            console.log("User Logged In");
            result = true;
        } else {
            // No user is signed in.
            console.log("User Logged Out");
            result = false;
        }
        cb(result,user);
    });
}

function logout() {
    console.log(firebase.auth().currentUser);
    firebase.auth().signOut().then(function () {
        console.log(firebase.auth().currentUser);
        window.location.replace('/index.html');
    }).catch(function (error) {
        // An error happened.
    });
}